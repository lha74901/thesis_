# employee_predictor/tests__/test_utils.py
from django.test import TestCase
from datetime import date, timedelta
from decimal import Decimal

from employee_predictor.models import Employee, Attendance
from employee_predictor.utils import calculate_payroll_details


class UtilsTest(TestCase):
    def setUp(self):
        # Create employee
        self.employee = Employee.objects.create(
            name='Test Employee',
            emp_id='EMP001',
            department='IT',
            position='Developer',
            date_of_hire=date(2020, 1, 1),
            gender='M',
            marital_status='Single',
            salary=Decimal('60000.00'),
            engagement_survey=4.0,
            emp_satisfaction=4,
            special_projects_count=2,
            days_late_last_30=1,
            absences=3
        )

        # Create attendance records
        today = date.today()
        # Create attendance for the last 22 days (a typical work month)
        for day_offset in range(22):
            current_date = today - timedelta(days=day_offset)
            if day_offset < 15:  # 15 present days
                status = 'PRESENT'
                hours = 8.0
            elif day_offset < 18:  # 3 late days
                status = 'LATE'
                hours = 6.0
            elif day_offset < 20:  # 2 absent days
                status = 'ABSENT'
                hours = 0.0
            else:  # 2 on-leave days
                status = 'ON_LEAVE'
                hours = 0.0

            Attendance.objects.create(
                employee=self.employee,
                date=current_date,
                status=status,
                hours_worked=Decimal(str(hours))
            )

    def test_calculate_payroll_details_full_month(self):
        """Test payroll calculation for a full month"""
        # Define date range for a full month
        end_date = date.today()
        start_date = date(end_date.year, end_date.month, 1)

        # Calculate payroll details
        details = calculate_payroll_details(self.employee, start_date, end_date)

        # Check result structure
        self.assertIn('attendance_stats', details)
        self.assertIn('overtime_hours', details)
        self.assertIn('overtime_rate', details)
        self.assertIn('estimated_tax', details)

        # Check attendance stats
        stats = details['attendance_stats']
        self.assertIn('present_days', stats)
        self.assertIn('absent_days', stats)
        self.assertIn('late_days', stats)
        self.assertIn('total_hours', stats)

        # Verify calculations are correct
        self.assertGreaterEqual(details['overtime_rate'], 0)
        self.assertGreaterEqual(details['estimated_tax'], 0)

    def test_calculate_payroll_details_partial_month(self):
        """Test payroll calculation for a partial month"""
        # Define date range for just one week
        end_date = date.today()
        start_date = end_date - timedelta(days=7)

        # Calculate payroll details
        details = calculate_payroll_details(self.employee, start_date, end_date)

        # Check result structure and calculations
        self.assertIn('attendance_stats', details)
        self.assertIn('overtime_hours', details)

        # Check overtime calculation with fewer days
        self.assertEqual(type(details['overtime_hours']), int)

    def test_calculate_payroll_details_no_attendance(self):
        """Test payroll calculation with no attendance records"""
        # Use date range with no attendance records
        future_date = date.today() + timedelta(days=30)
        start_date = future_date
        end_date = future_date + timedelta(days=30)

        # Calculate payroll details
        details = calculate_payroll_details(self.employee, start_date, end_date)

        # Check default values for empty period
        self.assertEqual(details['attendance_stats']['present_days'], 0)
        self.assertEqual(details['attendance_stats']['absent_days'], 0)
        self.assertEqual(details['attendance_stats']['late_days'], 0)
        self.assertEqual(details['attendance_stats']['total_hours'], 0)
        self.assertEqual(details['overtime_hours'], 0)
