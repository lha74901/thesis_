# employee_predictor/tests__/test_api.py
from django.test import TestCase, Client, RequestFactory
from django.urls import reverse
from django.contrib.auth.models import User
from datetime import date
from decimal import Decimal
import json
from unittest import mock
# Correct absolute imports
from employee_predictor.models import Employee, Attendance
from employee_predictor.tests.test_helper import axes_login
from employee_predictor.api import get_employee_salary_info


# No need to import calculate_payroll_details here


class EmployeeAPITest(TestCase):
    def setUp(self):
        # Create staff user
        self.staff_user = User.objects.create_user(
            username='staffuser',
            password='staffpassword',
            is_staff=True
        )

        # Create employee
        self.employee = Employee.objects.create(
            name='Test Employee',
            emp_id='EMP001',
            department='IT',
            position='Developer',
            date_of_hire=date(2020, 1, 1),
            gender='M',
            marital_status='Single',
            salary=Decimal('60000.00'),
            engagement_survey=4.0,
            emp_satisfaction=4,
            special_projects_count=2,
            days_late_last_30=1,
            absences=3,
            hispanic_latino='No',
            employment_status='Active'
        )

        # Create attendance records
        today = date.today()
        Attendance.objects.create(
            employee=self.employee,
            date=today,
            status='PRESENT',
            hours_worked=Decimal('8.00')
        )

        # Create client
        self.client = Client()

    def test_get_employee_salary_info_authenticated(self):
        """Test API returns salary info for authenticated users"""
        # Login via client
        axes_login(self.client, 'staffuser', 'staffpassword')

        # Make API request through the client
        response = self.client.get(
            reverse('api-employee-salary', args=[self.employee.id])
        )

        # Check response
        self.assertEqual(response.status_code, 200)
        data = json.loads(response.content)

        # Validate response data
        self.assertEqual(data['employee_id'], self.employee.id)
        self.assertEqual(data['name'], 'Test Employee')
        self.assertEqual(float(data['salary']), 60000.00)
        self.assertIn('overtime_rate', data)

    def test_get_employee_salary_info_with_dates(self):
        """Test API with custom date parameters"""
        # Login
        axes_login(self.client, 'staffuser', 'staffpassword')

        # Make API request with date parameters
        response = self.client.get(
            reverse('api-employee-salary', args=[self.employee.id]),
            {'start_date': '2023-01-01', 'end_date': '2023-01-31'}
        )

        # Check response
        self.assertEqual(response.status_code, 200)
        data = json.loads(response.content)

        # Validate response contains expected fields
        self.assertIn('employee_id', data)
        self.assertIn('attendance_stats', data)

    def test_get_employee_salary_info_invalid_employee(self):
        """Test API with invalid employee ID"""
        # Login
        axes_login(self.client, 'staffuser', 'staffpassword')

        # Make API request with non-existent employee ID
        response = self.client.get(
            reverse('api-employee-salary', args=[9999])  # Non-existent ID
        )

        # Should return 400 status code
        self.assertEqual(response.status_code, 400)
        data = json.loads(response.content)
        self.assertIn('error', data)

    def test_api_error_handling(self):
        """Test API error handling scenarios"""
        # Login
        axes_login(self.client, 'staffuser', 'staffpassword')

        # Test with malformed date
        response = self.client.get(
            reverse('api-employee-salary', args=[self.employee.id]),
            {'start_date': 'invalid-date', 'end_date': '2023-01-31'}
        )

        # Should return 400 for invalid date format
        self.assertEqual(response.status_code, 400)
        data = json.loads(response.content)
        self.assertIn('error', data)

    def test_december_date_handling(self):
        """Test API handles December date rollover correctly"""
        # Login
        axes_login(self.client, 'staffuser', 'staffpassword')

        # Mock today's date to be in December
        with mock.patch('employee_predictor.api.date') as mock_date:
            mock_date.today.return_value = date(2023, 12, 15)
            # The actual date.today() is patched but we still need a real date instance for other operations
            mock_date.side_effect = lambda *args, **kw: date(*args, **kw)

            # Make API request without date parameters to trigger default date logic
            response = self.client.get(
                reverse('api-employee-salary', args=[self.employee.id])
            )

            # Check response
            self.assertEqual(response.status_code, 200)
            data = json.loads(response.content)

            # Verify data contains expected fields
            self.assertIn('employee_id', data)
            self.assertIn('attendance_stats', data)

    def test_general_exception_handling(self):
        """Test API handles unexpected errors gracefully"""
        # Login
        axes_login(self.client, 'staffuser', 'staffpassword')

        # Mock calculate_payroll_details to raise an exception
        with mock.patch('employee_predictor.api.calculate_payroll_details') as mock_calc:
            mock_calc.side_effect = Exception("Test exception")

            # Make API request
            response = self.client.get(
                reverse('api-employee-salary', args=[self.employee.id])
            )

            # Should return 400 with error message
            self.assertEqual(response.status_code, 400)
            data = json.loads(response.content)
            self.assertIn('error', data)
            self.assertEqual(data['error'], "Test exception")