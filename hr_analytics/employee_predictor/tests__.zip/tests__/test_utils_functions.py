# employee_predictor/tests__/test_utils_functions.py
from django.test import TestCase, Client
from django.contrib.auth.models import User
from django.contrib.auth import SESSION_KEY

# Import the function to test
from employee_predictor.tests.utils import axes_login


class UtilsTestCase(TestCase):
    """Test case for utils.py functions"""

    def setUp(self):
        """Set up test data"""
        # Create test users
        self.valid_user = User.objects.create_user(
            username='valid_user',
            password='valid_password',
            email='valid@example.com'
        )

        self.inactive_user = User.objects.create_user(
            username='inactive_user',
            password='inactive_password',
            email='inactive@example.com',
            is_active=False
        )

        # Create client
        self.client = Client()

    def test_axes_login_success(self):
        """Test successful login with axes_login function"""
        # Use the function with valid credentials
        result = axes_login(self.client, 'valid_user', 'valid_password')

        # Check that login was successful
        self.assertTrue(result)
        self.assertTrue(SESSION_KEY in self.client.session)

        # Verify session contains correct user
        self.assertEqual(int(self.client.session[SESSION_KEY]), self.valid_user.id)

    def test_axes_login_failure_wrong_password(self):
        """Test login failure with incorrect password"""
        # Use the function with wrong password
        result = axes_login(self.client, 'valid_user', 'wrong_password')

        # Check that login failed
        self.assertFalse(result)
        self.assertFalse(SESSION_KEY in self.client.session)

    def test_axes_login_failure_nonexistent_user(self):
        """Test login failure with nonexistent username"""
        # Use the function with nonexistent username
        result = axes_login(self.client, 'nonexistent_user', 'any_password')

        # Check that login failed
        self.assertFalse(result)
        self.assertFalse(SESSION_KEY in self.client.session)

    def test_axes_login_inactive_user(self):
        """Test login failure with inactive user"""
        # Use the function with inactive user
        result = axes_login(self.client, 'inactive_user', 'inactive_password')

        # Check that login failed (inactive users cannot log in)
        self.assertFalse(result)
        self.assertFalse(SESSION_KEY in self.client.session)

    def test_axes_login_with_kwargs(self):
        """Test passing additional kwargs to authenticate"""
        # Use the function with additional kwargs
        result = axes_login(
            self.client,
            'valid_user',
            'valid_password',
            # Additional kwargs for authenticate
            backend='django.contrib.auth.backends.ModelBackend'
        )

        # Check that login was successful
        self.assertTrue(result)
        self.assertTrue(SESSION_KEY in self.client.session)