import os
import pandas as pd
import numpy as np
import tempfile
import shutil
from unittest import mock
from django.test import TestCase
from django.conf import settings
from datetime import datetime, date
from decimal import Decimal
from sklearn.preprocessing import LabelEncoder, StandardScaler, MinMaxScaler, OneHotEncoder
from sklearn.compose import ColumnTransformer

from employee_predictor.ml.feature_engineering import (
    get_preprocessor, load_preprocessor, save_preprocessor,
    load_label_encoders, save_label_encoders, prepare_data_for_prediction,
    engineer_features, MINMAX_FEATURES, ZSCORE_FEATURES, LABEL_FEATURES, ONEHOT_FEATURES
)


class AdditionalFeatureEngineeringTests(TestCase):
    """Additional tests__ to improve coverage for feature_engineering.py."""

    def setUp(self):
        """Set up test data and temporary directory for saved models."""
        # Create a temporary directory for test models
        self.temp_media_root = tempfile.mkdtemp()
        self.original_media_root = settings.MEDIA_ROOT
        settings.MEDIA_ROOT = self.temp_media_root

        # Create test employee data
        self.employee_data = {
            'emp_id': ['EMP001'],
            'name': ['Test Employee'],
            'date_of_hire': [date(2020, 1, 1)],
            'department': ['IT'],
            'position': ['Developer'],
            'gender': ['M'],
            'marital_status': ['Single'],
            'age': [30],
            'race': ['White'],
            'hispanic_latino': ['No'],
            'recruitment_source': ['LinkedIn'],
            'salary': [60000.00],
            'engagement_survey': [4.0],
            'emp_satisfaction': [4],
            'special_projects_count': [2],
            'days_late_last_30': [1],
            'absences': [3],
            'employment_status': ['Active']
        }

        # Create a real preprocessor for testing
        self.minmax_scaler = MinMaxScaler()
        self.zscore_scaler = StandardScaler()
        self.onehot_encoder = OneHotEncoder(drop='first', sparse_output=False, handle_unknown='ignore')

        # Fit the preprocessor with sample data
        sample_data = pd.DataFrame({
            'DaysLateLast30': [0, 1, 2, 3],
            'Absences': [0, 1, 2, 3],
            'SpecialProjectsCount': [0, 1, 2, 3],
            'EngagementSurvey': [1.0, 2.0, 3.0, 4.0],
            'EmpSatisfaction': [1, 2, 3, 4],
            'Salary': [50000, 60000, 70000, 80000],
            'Tenure_Years': [1, 2, 3, 4],
            'Age': [25, 30, 35, 40],
            'Sex': [0, 1, 0, 1],
            'EmploymentStatus': [0, 1, 2, 0],
            'Position': ['Developer', 'Manager', 'Analyst', 'HR'],
            'RaceDesc': ['White', 'Black', 'Asian', 'Hispanic'],
            'RecruitmentSource': ['LinkedIn', 'Indeed', 'Referral', 'Agency'],
            'MaritalDesc': ['Single', 'Married', 'Divorced', 'Single'],
            'Department': ['IT', 'Sales', 'Marketing', 'Finance']
        })

        # Create the column transformer
        self.preprocessor = ColumnTransformer(
            transformers=[
                ('minmax', self.minmax_scaler, MINMAX_FEATURES),
                ('zscore', self.zscore_scaler, ZSCORE_FEATURES),
                ('onehot', self.onehot_encoder, ONEHOT_FEATURES)
            ],
            remainder='passthrough'
        )

        # Fit the preprocessor
        self.preprocessor.fit(sample_data)

        # Save the preprocessor
        save_preprocessor(self.preprocessor)

        # Create and save label encoders
        self.label_encoders = {}
        for feature in LABEL_FEATURES:
            le = LabelEncoder()
            if feature == 'Sex':
                le.fit(['M', 'F'])
            elif feature == 'EmploymentStatus':
                le.fit(['Active', 'Voluntarily Terminated', 'Terminated for Cause'])
            self.label_encoders[feature] = le

        save_label_encoders(self.label_encoders)

    def tearDown(self):
        """Clean up temporary directory."""
        settings.MEDIA_ROOT = self.original_media_root
        shutil.rmtree(self.temp_media_root)

    def test_with_dict_input(self):
        """Test prepare_data_for_prediction with dictionary input."""
        # Create a dictionary input WITH LIST VALUES (key difference from previous version)
        data = {
            'emp_id': ['EMP001'],
            'name': ['Test Dict Employee'],
            'date_of_hire': [date(2020, 1, 1)],
            'department': ['IT'],
            'position': ['Developer'],
            'gender': ['M'],
            'marital_status': ['Single'],
            'age': [30],
            'race': ['White'],
            'hispanic_latino': ['No'],
            'recruitment_source': ['LinkedIn'],
            'salary': [60000.00],
            'engagement_survey': [4.0],
            'emp_satisfaction': [4],
            'special_projects_count': [2],
            'days_late_last_30': [1],
            'absences': [3],
            'employment_status': ['Active']
        }

        # Call the function with the dictionary
        result = prepare_data_for_prediction(data)

        # Verify the result is a numpy array
        self.assertIsInstance(result, np.ndarray)

    def test_with_series_dict_input(self):
        """Test prepare_data_for_prediction with dictionary of pandas Series."""
        # Create a dictionary with Series as values
        data = {
            'emp_id': pd.Series(['EMP001S']),
            'name': pd.Series(['Series Employee']),
            'date_of_hire': pd.Series([date(2020, 1, 1)]),
            'department': pd.Series(['IT']),
            'position': pd.Series(['Developer']),
            'gender': pd.Series(['M']),
            'salary': pd.Series([60000.00]),
            'employment_status': pd.Series(['Active'])
        }

        # Call the function
        result = prepare_data_for_prediction(data)

        # Verify the result is a numpy array
        self.assertIsInstance(result, np.ndarray)

    def test_with_birth_date_instead_of_age(self):
        """Test prepare_data_for_prediction with birth_date instead of age."""
        # Create data with birth_date instead of age
        data = pd.DataFrame({
            'emp_id': ['EMP002'],
            'name': ['Another Employee'],
            'date_of_hire': [date(2019, 5, 15)],
            'department': ['Sales'],
            'position': ['Sales Manager'],
            'gender': ['F'],
            'marital_status': ['Married'],
            'birth_date': [date(1990, 3, 10)],  # Instead of age
            'race': ['Black'],
            'hispanic_latino': ['No'],
            'recruitment_source': ['Agency'],
            'salary': [75000.00],
            'engagement_survey': [3.5],
            'emp_satisfaction': [3],
            'special_projects_count': [1],
            'days_late_last_30': [0],
            'absences': [2],
            'employment_status': ['Active']
        })

        # Call the function
        result = prepare_data_for_prediction(data)

        # Verify the result is a numpy array
        self.assertIsInstance(result, np.ndarray)

    def test_with_completely_missing_data(self):
        """Test prepare_data_for_prediction with completely missing data."""
        # Create minimal data
        data = pd.DataFrame({
            'emp_id': ['EMP003'],
            'name': ['Minimal Employee'],
            # All other fields are missing
        })

        # Call the function
        result = prepare_data_for_prediction(data)

        # Verify the result is a numpy array
        self.assertIsInstance(result, np.ndarray)

    def test_with_real_preprocessing_error(self):
        """Test error handling in prepare_data_for_prediction."""
        # Create incompatible data that will cause preprocessing error
        data = pd.DataFrame({
            'DaysLateLast30': ['invalid'],  # String instead of numeric
            'Absences': ['invalid'],
            'SpecialProjectsCount': ['invalid'],
            'EngagementSurvey': ['invalid'],
            'EmpSatisfaction': ['invalid'],
            'Salary': ['invalid'],
            'Tenure_Years': ['invalid'],
            'Age': ['invalid'],
            'Sex': ['invalid'],
            'EmploymentStatus': ['invalid'],
            'Position': [None],
            'RaceDesc': [None],
            'RecruitmentSource': [None],
            'MaritalDesc': [None],
            'Department': [None]
        })

        # Mock print to avoid cluttering test output
        with mock.patch('builtins.print'):
            # Check that it raises ValueError
            with self.assertRaises(ValueError):
                prepare_data_for_prediction(data)

    def test_with_alternative_gender_mapping(self):
        """Test with alternative gender mapping."""
        # Create data with non-standard gender values
        data = pd.DataFrame({
            'emp_id': ['EMP004'],
            'name': ['Gender Test Employee'],
            'gender': ['Female'],  # Instead of 'F'
            'position': ['Developer'],
            'department': ['IT'],
            'salary': [65000.00],
            'employment_status': ['Active']
        })

        # Call the function
        result = prepare_data_for_prediction(data)

        # Verify the result is a numpy array
        self.assertIsInstance(result, np.ndarray)

    def test_with_alternative_employment_status_mapping(self):
        """Test with alternative employment status mapping."""
        # Create data with non-standard employment status
        data = pd.DataFrame({
            'emp_id': ['EMP005'],
            'name': ['Status Test Employee'],
            'gender': ['M'],
            'position': ['Developer'],
            'department': ['IT'],
            'salary': [65000.00],
            'employment_status': ['Resigned']  # Non-standard value
        })

        # Call the function
        result = prepare_data_for_prediction(data)

        # Verify the result is a numpy array
        self.assertIsInstance(result, np.ndarray)

    @mock.patch('employee_predictor.ml.feature_engineering.LABEL_FEATURES',
                LABEL_FEATURES + ['custom_label'])
    def test_with_custom_label_features(self):
        """Test with custom label features not in standard mapping."""
        # Create data with a custom label feature
        data = pd.DataFrame({
            'emp_id': ['EMP006'],
            'name': ['Label Test Employee'],
            'gender': ['M'],
            'position': ['Developer'],
            'department': ['IT'],
            'salary': [65000.00],
            'employment_status': ['Active'],
            'custom_label': ['Value1']  # Custom label feature
        })

        # Call the function
        result = prepare_data_for_prediction(data)

        # Verify the result is a numpy array
        self.assertIsInstance(result, np.ndarray)

    def test_with_missing_preprocessor_error(self):
        """Test error when preprocessor is missing."""
        # Mock load_preprocessor to return None
        with mock.patch('employee_predictor.ml.feature_engineering.load_preprocessor') as mock_load:
            mock_load.return_value = None

            # Should raise ValueError with specific message
            with self.assertRaises(ValueError) as context:
                prepare_data_for_prediction(self.employee_data)

            # Check error message
            self.assertIn("Preprocessor not found", str(context.exception))

    def test_engineer_features_direct(self):
        """Test the engineer_features function directly."""
        # Call engineer_features directly
        result = engineer_features(self.employee_data)

        # Verify the result is a numpy array
        self.assertIsInstance(result, np.ndarray)

    def test_no_label_encoders(self):
        """Test behavior when no label encoders are available."""
        # Delete label encoders file
        models_dir = os.path.join(self.temp_media_root, 'models')
        encoders_path = os.path.join(models_dir, 'label_encoders.pkl')
        if os.path.exists(encoders_path):
            os.remove(encoders_path)

        # Create minimal data
        data = pd.DataFrame({
            'emp_id': ['EMP007'],
            'name': ['No Encoders Employee'],
            'gender': ['M'],
            'position': ['Developer'],
            'department': ['IT'],
            'salary': [65000.00],
            'employment_status': ['Active']
        })

        # Call function with missing encoders
        result = prepare_data_for_prediction(data)

        # Verify the result is a numpy array
        self.assertIsInstance(result, np.ndarray)

    def test_with_preprocessing_exception_details(self):
        """Test handling of preprocessing exceptions with detailed error info."""
        # Create a mock preprocessor that raises a specific exception
        with mock.patch('employee_predictor.ml.feature_engineering.load_preprocessor') as mock_load:
            mock_preprocessor = mock.MagicMock()
            mock_preprocessor.transform.side_effect = ValueError("Column mismatch")
            mock_load.return_value = mock_preprocessor

            # Mock print to avoid cluttering test output
            with mock.patch('builtins.print'):
                # Should raise ValueError with specific message
                with self.assertRaises(ValueError) as context:
                    prepare_data_for_prediction(self.employee_data)

                # Check that the error message contains the original exception info
                self.assertIn("Failed to preprocess features", str(context.exception))

    def test_get_preprocessor_direct(self):
        """Test the get_preprocessor function directly."""
        preprocessor = get_preprocessor()

        # Verify structure
        self.assertIsInstance(preprocessor, ColumnTransformer)
        self.assertEqual(len(preprocessor.transformers), 3)

        # Check transformer types
        self.assertIsInstance(preprocessor.transformers[0][1], MinMaxScaler)
        self.assertIsInstance(preprocessor.transformers[1][1], StandardScaler)
        self.assertIsInstance(preprocessor.transformers[2][1], OneHotEncoder)

    def test_non_numeric_conversion_error(self):
        """Test handling of non-numeric conversion errors."""
        # Create data with values that can't be converted to numeric
        data = pd.DataFrame({
            'emp_id': ['EMP008'],
            'name': ['Conversion Test Employee'],
            'gender': ['M'],
            'salary': ['Not a number'],  # This will cause a conversion error
            'employment_status': ['Active']
        })

        # Call function and verify it handles the error gracefully
        result = prepare_data_for_prediction(data)
        self.assertIsInstance(result, np.ndarray)

    def test_custom_label_encoder_mapping(self):
        """Test with custom label encoder that isn't in standard mappings."""
        # Create a custom label encoder
        custom_le = LabelEncoder()
        custom_le.fit(['Value1', 'Value2', 'Value3'])

        # Mock the load_label_encoders function to return our custom encoder
        with mock.patch('employee_predictor.ml.feature_engineering.load_label_encoders') as mock_load:
            mock_load.return_value = {'CustomFeature': custom_le}

            # Set up data with the custom feature
            data = pd.DataFrame({
                'emp_id': ['EMP009'],
                'CustomFeature': ['Value2'],  # Should be encoded as 1
                'gender': ['M'],
                'employment_status': ['Active']
            })

            # Add CustomFeature to LABEL_FEATURES temporarily
            with mock.patch('employee_predictor.ml.feature_engineering.LABEL_FEATURES',
                            LABEL_FEATURES + ['CustomFeature']):
                # Call function
                result = prepare_data_for_prediction(data)
                self.assertIsInstance(result, np.ndarray)

    def test_with_empty_dataframe(self):
        """Test with completely empty DataFrame."""
        # Create empty DataFrame
        data = pd.DataFrame()

        # Should handle gracefully and fill with defaults
        result = prepare_data_for_prediction(data)
        self.assertIsInstance(result, np.ndarray)

    def test_with_mixed_types_in_columns(self):
        """Test with mixed types in columns that require conversion."""
        # Create data with mixed types - fixed to have consistent lengths
        data = pd.DataFrame({
            'emp_id': ['EMP010', 'EMP011'],
            'engagement_survey': [4.0, 'High'],  # Mixed numeric and string
            'absences': [3, '2'],  # Mixed int and string
            'gender': ['M', 'F'],
            'employment_status': ['Active', 'Voluntarily Terminated']
        })

        # Call function
        result = prepare_data_for_prediction(data)
        self.assertIsInstance(result, np.ndarray)

    # Add to employee_predictor/tests__/test_feature_engineering.py
    def test_transform_exception(self):
        """Test exception handling in the transform step."""
        # Create valid data that will pass initial validation
        data = pd.DataFrame({
            'emp_id': ['EMP012'],
            'gender': ['M'],
            'position': ['Developer'],
            'department': ['IT'],
            'salary': [65000.00],
            'employment_status': ['Active']
        })

        # Mock the load_preprocessor function to return a mock preprocessor
        with mock.patch('employee_predictor.ml.feature_engineering.load_preprocessor') as mock_load:
            # Create a mock preprocessor
            mock_preprocessor = mock.MagicMock()
            # Set up the transform method to raise an exception
            mock_preprocessor.transform.side_effect = Exception("Transform error")
            # Return our mock preprocessor when load_preprocessor is called
            mock_load.return_value = mock_preprocessor

            # Mock print to avoid cluttering test output
            with mock.patch('builtins.print'):
                # Check that it raises ValueError with the expected message
                with self.assertRaises(ValueError) as context:
                    prepare_data_for_prediction(data)

                # Verify the exception message contains our original error
                self.assertIn("Failed to preprocess features", str(context.exception))

    # Add to employee_predictor/tests__/test_feature_engineering.py
    def test_dataframe_with_invalid_column_types(self):
        """Test with DataFrame having incompatible column types."""

        # Create a DataFrame with columns that have invalid types
        # This is different from previous tests__ by having complex objects
        class ComplexObject:
            def __str__(self):
                return "ComplexObject"

        data = pd.DataFrame({
            'emp_id': ['EMP013'],
            'gender': ['M'],
            'position': [ComplexObject()],  # This should cause issues in conversion
            'department': ['IT'],
            'salary': [65000.00],
            'employment_status': ['Active']
        })

        # Mock print to avoid cluttering test output
        with mock.patch('builtins.print'):
            # It should handle or raise appropriately
            result = prepare_data_for_prediction(data)
            self.assertIsInstance(result, np.ndarray)

    # Add to employee_predictor/tests__/test_feature_engineering.py
    def test_preprocessing_dtypes_debug(self):
        """Test that targets the debug print of feature dtypes."""
        # Create valid data that will pass initial validation
        data = pd.DataFrame({
            'emp_id': ['EMP013'],
            'gender': ['M'],
            'position': ['Developer'],
            'department': ['IT'],
            'salary': [65000.00],
            'employment_status': ['Active']
        })

        # Mock the transform method to specifically raise a TypeError
        with mock.patch('employee_predictor.ml.feature_engineering.load_preprocessor') as mock_load:
            # Create a mock preprocessor
            mock_preprocessor = mock.MagicMock()
            # Set up transform to raise a TypeError with a specific message
            mock_preprocessor.transform.side_effect = TypeError("Could not convert data type")
            mock_load.return_value = mock_preprocessor

            # We need to specifically NOT mock print here to ensure the debug print happens
            with self.assertRaises(ValueError) as context:
                prepare_data_for_prediction(data)

            # Verify the error message indicates the failure
            self.assertIn("Failed to preprocess features", str(context.exception))

    def test_custom_label_feature_with_exception(self):
        """Test the conversion exception path for custom label features."""
        # Create a custom LABEL_FEATURES list with a new feature
        with mock.patch('employee_predictor.ml.feature_engineering.LABEL_FEATURES',
                        LABEL_FEATURES + ['custom_complex_feature']):
            # Create data with a custom label feature - ensure all arrays have same length
            data = pd.DataFrame({
                'emp_id': ['EMP014'],
                'gender': ['M'],
                'position': ['Developer'],
                'department': ['IT'],
                'employment_status': ['Active'],
                'custom_complex_feature': ['Value1']  # Now matches other arrays' length
            })

            # We'll need our own label encoder for this feature
            custom_le = LabelEncoder()
            custom_le.fit(['Value1', 'Value2', 'Value3'])

            # Create a label encoders dictionary with our custom encoder
            with mock.patch('employee_predictor.ml.feature_engineering.load_label_encoders') as mock_load:
                mock_load.return_value = {'custom_complex_feature': custom_le}

                # This should trigger the exception path in the label encoding section
                result = prepare_data_for_prediction(data)

                # Verify the result is a numpy array
                self.assertIsInstance(result, np.ndarray)


    def test_mixed_type_dataframe_conversion(self):
        """Test with DataFrame having multiple rows with mixed types."""
        # Create a DataFrame with multiple rows and mixed types
        data = pd.DataFrame({
            'emp_id': ['EMP016', 'EMP017'],
            'gender': ['M', 'F'],
            'position': ['Developer', 'Manager'],
            'department': ['IT', 'HR'],
            'employment_status': ['Active', 'Active'],
            # Create columns with mixed types that require conversion
            'engagement_survey': [4.5, None],  # Mix float and None
            'emp_satisfaction': [4, 'High'],  # Mix int and string
            'special_projects_count': [2, '3'],  # Mix int and string
            'days_late_last_30': [1, np.nan],  # Mix int and NaN
            'absences': [3, None]  # Mix int and None
        })

        # This should trigger various type conversion paths
        result = prepare_data_for_prediction(data)
        self.assertIsInstance(result, np.ndarray)

    def test_unusual_data_types(self):
        """Test with unusual data types that require special handling."""
        # Create a DataFrame with unusual data types
        data = pd.DataFrame({
            'emp_id': ['EMP021'],
            'gender': ['M'],
            'position': ['Developer'],
            'department': ['IT'],
            'employment_status': ['Active'],
            # Use complex number for numeric field
            'salary': [complex(60000, 0)],
            # Use a list for numeric field
            'engagement_survey': [[4.0]],
            # Use a dictionary for numeric field
            'special_projects_count': [{'count': 2}]
        })

        # This should trigger various conversion paths
        result = prepare_data_for_prediction(data)
        self.assertIsInstance(result, np.ndarray)


class FeatureEngineeringEdgeCasesTest(TestCase):
    # Add to test_feature_engineering.py
    def test_with_all_invalid_data(self):
        """Test feature engineering with all invalid data."""
        # Create dataframe with all invalid values
        invalid_data = pd.DataFrame({
            'DaysLateLast30': ['invalid', 'invalid'],
            'Absences': ['invalid', 'invalid'],
            'Salary': ['invalid', 'invalid'],
            'SpecialProjectsCount': ['invalid', 'invalid'],
            'EngagementSurvey': ['invalid', 'invalid'],
            'EmpSatisfaction': ['invalid', 'invalid']
        })

        # This should trigger an exception path
        with self.assertRaises(ValueError):
            prepare_data_for_prediction(invalid_data)


