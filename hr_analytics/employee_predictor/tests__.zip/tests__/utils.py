# Create this file as employee_predictor/tests__/utils.py
from django.test import RequestFactory
from django.contrib.auth import authenticate


def axes_login(client, username, password, **kwargs):
    """
    Login method that works with django-axes by providing a request object.

    Args:
        client: The test client
        username: The username to log in with
        password: The password to log in with
        **kwargs: Any additional parameters to pass to authenticate

    Returns:
        True if login was successful, False otherwise
    """
    request_factory = RequestFactory()
    request = request_factory.get('/')
    request.session = client.session

    # Include request in auth credentials
    auth_kwargs = {'request': request, 'username': username, 'password': password}
    auth_kwargs.update(kwargs)

    # Authenticate with request
    user = authenticate(**auth_kwargs)

    if user:
        # Manually log in without going through authenticate again
        client.force_login(user)
        return True
    return False