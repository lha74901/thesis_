# employee_predictor/tests__/test_middleware.py
from django.test import TestCase, Client
from django.urls import reverse
from django.contrib.auth.models import User
from decimal import Decimal
from datetime import date

from employee_predictor.models import Employee

from employee_predictor.tests.test_helper import axes_login

class EmployeePortalMiddlewareTest(TestCase):
    def setUp(self):
        # Create a staff user
        self.staff_user = User.objects.create_user(
            username='staffuser',
            password='staffpassword',
            is_staff=True
        )

        # Create a non-staff employee user
        self.employee_user = User.objects.create_user(
            username='employeeuser',
            password='employeepassword',
            is_staff=False
        )

        # Create an employee record linked to the employee user
        self.employee = Employee.objects.create(
            user=self.employee_user,
            name='Test Employee',
            emp_id='EMP001',
            department='IT',
            position='Developer',
            date_of_hire=date(2020, 1, 1),
            gender='M',
            marital_status='Single',
            salary=Decimal('60000.00'),
            engagement_survey=4.0,
            emp_satisfaction=4,
            special_projects_count=2,
            days_late_last_30=1,
            absences=3
        )

        # Create client
        self.client = Client()

    def test_employee_access_to_admin_urls(self):
        # Login as employee
        axes_login(self.client, 'employeeuser', 'employeepassword')

        # Try to access admin URLs
        admin_urls = [
            reverse('employee-list'),
            reverse('attendance-list'),
            reverse('leave-list'),
            reverse('payroll-list')
        ]

        for url in admin_urls:
            response = self.client.get(url)
            self.assertRedirects(response, reverse('employee-portal'))

    def test_staff_access_to_admin_urls(self):
        # Login as staff
        axes_login(self.client, 'staffuser', 'staffpassword')

        # Try to access admin URLs
        admin_urls = [
            reverse('employee-list'),
            reverse('attendance-list'),
            reverse('leave-list'),
            reverse('payroll-list')
        ]

        for url in admin_urls:
            response = self.client.get(url)
            self.assertEqual(response.status_code, 200)

    def test_staff_access_to_employee_portal(self):
        # Login as staff
        axes_login(self.client, 'staffuser', 'staffpassword')

        # Try to access employee portal
        response = self.client.get(reverse('employee-portal'))

        # Should be redirected to dashboard
        self.assertRedirects(response, reverse('dashboard'))

    # Add to test_middleware.py
    def test_middleware_with_invalid_url(self):
        """Test middleware behavior with non-existent URLs."""
        # Login as employee
        axes_login(self.client, 'employeeuser', 'employeepassword')

        # Access a URL that doesn't exist but might match pattern
        response = self.client.get('/employee-invalid/')

        # Should return 404, not redirect
        self.assertEqual(response.status_code, 404)