# employee_predictor/tests__/test_template_tags.py
from django.test import TestCase
from decimal import Decimal

from employee_predictor.templatetags.hr_filters import multiply, percentage, subtract_from, abs_value


class HRFiltersTest(TestCase):
    def test_multiply_filter(self):
        """Test multiply filter with various inputs"""
        # Normal case
        self.assertEqual(multiply(5, 2), 10.0)

        # Decimal values
        self.assertEqual(multiply(Decimal('5.5'), 2), 11.0)

        # None values
        self.assertEqual(multiply(None, 5), 0)
        self.assertEqual(multiply(5, None), 0)

        # String values that can be converted
        self.assertEqual(multiply('5', 2), 10.0)

        # Invalid values
        self.assertEqual(multiply('abc', 2), 0)

    def test_percentage_filter(self):
        """Test percentage filter with various inputs"""
        # Normal case
        self.assertEqual(percentage(50, 100), 50.0)

        # Decimal values
        self.assertEqual(percentage(Decimal('25'), 100), 25.0)

        # None values
        self.assertEqual(percentage(None, 100), 0)

        # Zero division case
        self.assertEqual(percentage(50, 0), 0)
        self.assertEqual(percentage(50, None), 0)

        # String values that can be converted
        self.assertEqual(percentage('50', '100'), 50.0)

        # Invalid values
        self.assertEqual(percentage('abc', 100), 0)

    def test_subtract_from_filter(self):
        """Test subtract_from filter with various inputs"""
        # Normal case
        self.assertEqual(subtract_from(25, 100), 75.0)

        # Decimal values
        self.assertEqual(subtract_from(Decimal('25'), 100), 75.0)

        # None values
        self.assertEqual(subtract_from(None, 100), 100.0)
        self.assertEqual(subtract_from(25, None), -25.0)

        # String values that can be converted
        self.assertEqual(subtract_from('25', '100'), 75.0)

        # Invalid values
        self.assertEqual(subtract_from('abc', 100), 0)

    def test_abs_value_filter(self):
        """Test abs_value filter with various inputs"""
        # Positive value
        self.assertEqual(abs_value(5), 5.0)

        # Negative value
        self.assertEqual(abs_value(-5), 5.0)

        # Zero value
        self.assertEqual(abs_value(0), 0.0)

        # Decimal values
        self.assertEqual(abs_value(Decimal('-5.5')), 5.5)

        # String values that can be converted
        self.assertEqual(abs_value('-5'), 5.0)

        # Invalid values
        self.assertEqual(abs_value('abc'), 'abc')  # Returns original value