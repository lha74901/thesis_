import unittest
from unittest.mock import patch, MagicMock
import pandas as pd
from decimal import Decimal
from datetime import date, timedelta
import os
import numpy as np

from django.test import TestCase
from django.contrib.auth.models import User

from employee_predictor.ml.predictor import PerformancePredictor
from employee_predictor.models import Employee, Leave


class PredictorTests(TestCase):
    """Tests for the PerformancePredictor class."""

    def setUp(self):
        """Set up test data."""
        # Create a test user
        self.user = User.objects.create_user(
            username='testuser',
            password='password123',
            email='test@example.com'
        )

        # Create a test employee
        self.employee = Employee.objects.create(
            user=self.user,
            name='Test Employee',
            emp_id='EMP001',
            department='IT',
            position='Developer',
            date_of_hire=date(2020, 1, 1),
            gender='M',
            marital_status='Single',
            age=30,
            salary=Decimal('60000.00'),
            engagement_survey=4.0,
            emp_satisfaction=4,
            special_projects_count=2,
            days_late_last_30=1,
            absences=3
        )

        # Sample employee data for predictions - stored as a dictionary
        self.employee_data = {
            'engagement_survey': 4.0,
            'emp_satisfaction': 4,
            'days_late_last_30': 1,
            'absences': 3,
            'special_projects_count': 2
        }

        # Create DataFrame from employee data
        self.employee_df = pd.DataFrame([self.employee_data])

    def test_init_with_model_found(self):
        """Test initialization when model is found."""
        with patch('os.path.exists', return_value=True), \
                patch('joblib.load') as mock_load:
            mock_model = MagicMock()
            mock_load.return_value = mock_model

            predictor = PerformancePredictor()

            # Check that model was loaded
            self.assertEqual(predictor.model, mock_model)
            mock_load.assert_called_once()

    def test_init_with_model_not_found(self):
        """Test initialization when model is not found."""
        with patch('os.path.exists', return_value=False):
            predictor = PerformancePredictor()

            # Check that model is None
            self.assertIsNone(predictor.model)

    def test_init_with_load_exception(self):
        """Test initialization when model loading raises an exception."""
        with patch('os.path.exists', return_value=True), \
                patch('joblib.load', side_effect=Exception("Test exception")):
            # This should not raise an exception
            predictor = PerformancePredictor()

            # Check that model is None
            self.assertIsNone(predictor.model)

    def test_predict_success(self):
        """Test successful prediction."""
        predictor = PerformancePredictor()

        # Mock rules_based_prediction to return a fixed value
        with patch.object(predictor, 'rules_based_prediction', return_value=4):
            result = predictor.predict(self.employee_df)
            self.assertEqual(result, 4)

    def test_predict_exception(self):
        """Test predict method handles exceptions."""
        predictor = PerformancePredictor()

        # Mock rules_based_prediction to raise an exception
        with patch.object(predictor, 'rules_based_prediction', side_effect=Exception("Test exception")):
            result = predictor.predict(self.employee_df)

            # Should return default score of 3
            self.assertEqual(result, 3)

    def test_rules_based_prediction_dict_input(self):
        """Test rules_based_prediction with dict input."""
        predictor = PerformancePredictor()

        # FIXED: Wrap the dictionary in a list to create a DataFrame with proper index
        result = predictor.rules_based_prediction([self.employee_data])

        # With the given values, should return 4 (Exceeds)
        self.assertEqual(result, 4)

    def test_rules_based_prediction_df_input(self):
        """Test rules_based_prediction with DataFrame input."""
        predictor = PerformancePredictor()
        result = predictor.rules_based_prediction(self.employee_df)

        # With the given values, should return 4 (Exceeds)
        self.assertEqual(result, 4)

    def test_rules_based_prediction_alternative_column_names(self):
        """Test rules_based_prediction with alternative column names."""
        predictor = PerformancePredictor()

        # Create data with alternative column names
        alt_data = {
            'EngagementSurvey': 4.0,
            'EmpSatisfaction': 4,
            'DaysLateLast30': 1,
            'Absences': 3,
            'SpecialProjectsCount': 2
        }
        alt_df = pd.DataFrame([alt_data])

        result = predictor.rules_based_prediction(alt_df)

        # Should still return 4 (Exceeds)
        self.assertEqual(result, 4)

    def test_rules_based_prediction_low_scores(self):
        """Test rules_based_prediction with low scores."""
        predictor = PerformancePredictor()

        # Create data with low scores
        low_data = {
            'engagement_survey': 1.0,
            'emp_satisfaction': 1,
            'days_late_last_30': 10,
            'absences': 15,
            'special_projects_count': 0
        }
        low_df = pd.DataFrame([low_data])

        result = predictor.rules_based_prediction(low_df)

        # Should return 1 (PIP)
        self.assertEqual(result, 1)

    def test_rules_based_prediction_medium_scores(self):
        """Test rules_based_prediction with medium scores."""
        predictor = PerformancePredictor()

        # Create data with medium scores
        med_data = {
            'engagement_survey': 3.0,
            'emp_satisfaction': 3,
            'days_late_last_30': 5,
            'absences': 5,
            'special_projects_count': 1
        }
        med_df = pd.DataFrame([med_data])

        result = predictor.rules_based_prediction(med_df)

        # FIXED: The calculation should return 2 (Needs Improvement) based on the scoring formula
        # Calculation: (3.0-2.5) + (3.0-2.5) - (5*0.2) - (5*0.1) + (1*0.3) = 0.5 + 0.5 - 1.0 - 0.5 + 0.3 = -0.2
        # -0.2 is between -2 and 0, which maps to 2 (Needs Improvement)
        self.assertEqual(result, 2)

    def test_predict_with_probability(self):
        """Test predict_with_probability method."""
        predictor = PerformancePredictor()

        # Mock predict to return a fixed value
        with patch.object(predictor, 'predict', return_value=4):
            result = predictor.predict_with_probability(self.employee_df)

            # Check structure of result
            self.assertIn('prediction', result)
            self.assertIn('prediction_label', result)
            self.assertIn('probabilities', result)

            # Check values
            self.assertEqual(result['prediction'], 4)
            self.assertEqual(result['prediction_label'], 'Exceeds')

            # Check probabilities sum to approximately 1
            probs_sum = sum(result['probabilities'].values())
            self.assertAlmostEqual(probs_sum, 1.0, places=1)

            # Check highest probability is for predicted class
            self.assertEqual(max(result['probabilities'].items(), key=lambda x: x[1])[0], 4)

    def test_predict_with_probability_missing_mapping(self):
        """Test predict_with_probability when prediction is not in mapping."""
        predictor = PerformancePredictor()

        # Mock predict to return a value not in the mapping
        with patch.object(predictor, 'predict', return_value=None):
            result = predictor.predict_with_probability(self.employee_df)

            # Should still return valid structure with default values
            self.assertIn('prediction', result)
            self.assertIn('prediction_label', result)
            self.assertIn('probabilities', result)

            # Check that label is "Unknown" for missing mapping
            self.assertEqual(result['prediction_label'], "Unknown")

    def test_bulk_attendance_form_empty_submission(self):
        """Test BulkAttendanceForm with completely empty data."""
        from employee_predictor.forms import BulkAttendanceForm

        # Submit form with no data at all
        form = BulkAttendanceForm(data={}, files={})
        self.assertFalse(form.is_valid())

        # Check both required fields have errors
        self.assertIn('date', form.errors)
        self.assertIn('csv_file', form.errors)

    def test_leave_form_instance_validation(self):
        """Test LeaveForm validation when updating an existing instance."""
        from employee_predictor.forms import LeaveForm

        # Create a leave record
        leave = Leave.objects.create(
            employee=self.employee,
            start_date=date.today() - timedelta(days=10),
            end_date=date.today() - timedelta(days=5),
            leave_type='ANNUAL',
            status='APPROVED',
            reason='Pre-existing leave'
        )

        # Create form data for update
        form_data = {
            'employee': self.employee.id,
            'start_date': (date.today() + timedelta(days=5)).strftime('%Y-%m-%d'),
            'end_date': (date.today() + timedelta(days=10)).strftime('%Y-%m-%d'),
            'leave_type': 'SICK',
            'reason': 'Updated leave'
        }

        # Create form with instance to test that branch in clean() method
        form = LeaveForm(data=form_data, instance=leave)
        self.assertTrue(form.is_valid())

        # Save and verify
        updated_leave = form.save()
        self.assertEqual(updated_leave.leave_type, 'SICK')
        self.assertEqual(updated_leave.reason, 'Updated leave')

    def test_employee_form_with_no_data(self):
        """Test EmployeeForm with no data submission."""
        from employee_predictor.forms import EmployeeForm

        form = EmployeeForm(data={})
        self.assertFalse(form.is_valid())

        # Verify required fields are marked as errors
        required_fields = ['name', 'emp_id', 'department', 'position', 'date_of_hire',
                           'gender', 'salary', 'engagement_survey', 'emp_satisfaction',
                           'days_late_last_30', 'absences']
        for field in required_fields:
            self.assertIn(field, form.errors)

    def test_predict_with_probability_edge_cases(self):
        """Test predict_with_probability with edge case inputs."""
        predictor = PerformancePredictor()

        # Test with empty DataFrame
        empty_df = pd.DataFrame()
        result = predictor.predict_with_probability(empty_df)

        # Should still return a valid response structure
        self.assertIn('prediction', result)
        self.assertIn('prediction_label', result)
        self.assertIn('probabilities', result)

        # Test with different score values
        for score in [1, 2, 3, 4]:
            with patch.object(predictor, 'predict', return_value=score):
                result = predictor.predict_with_probability(self.employee_df)
                # Verify the highest probability matches the predicted score
                highest_prob = max(result['probabilities'].items(), key=lambda x: x[1])[0]
                self.assertEqual(highest_prob, score)

    def test_rules_based_prediction_missing_values(self):
        """Test rules_based_prediction with missing values in input."""
        predictor = PerformancePredictor()

        # Create data with missing values
        incomplete_data = {
            # Missing engagement_survey and emp_satisfaction
            'days_late_last_30': 1,
            'absences': 3,
            'special_projects_count': 2
        }
        incomplete_df = pd.DataFrame([incomplete_data])

        # Should handle missing values gracefully
        result = predictor.rules_based_prediction(incomplete_df)
        self.assertIn(result, [1, 2, 3, 4])  # Should be a valid score

    def test_rules_based_prediction_extreme_values(self):
        """Test rules_based_prediction with extreme values."""
        predictor = PerformancePredictor()

        # Create data with extreme positive values
        extreme_positive = {
            'engagement_survey': 5.0,  # Max possible
            'emp_satisfaction': 5,  # Max possible
            'days_late_last_30': 0,  # Best possible
            'absences': 0,  # Best possible
            'special_projects_count': 10  # Very high
        }
        positive_df = pd.DataFrame([extreme_positive])

        result = predictor.rules_based_prediction(positive_df)
        self.assertEqual(result, 4)  # Should be "Exceeds"

        # Create data with extreme negative values
        extreme_negative = {
            'engagement_survey': 1.0,  # Min possible
            'emp_satisfaction': 1,  # Min possible
            'days_late_last_30': 30,  # Worst possible (late every day)
            'absences': 30,  # Very high
            'special_projects_count': 0  # Worst possible
        }
        negative_df = pd.DataFrame([extreme_negative])

        result = predictor.rules_based_prediction(negative_df)
        self.assertEqual(result, 1)  # Should be "PIP"

    def test_predict_with_mixed_column_names(self):
        """Test predict with a mix of column naming conventions."""
        predictor = PerformancePredictor()

        # Create data with mixed naming conventions
        mixed_data = {
            'engagement_survey': 4.0,
            'EmpSatisfaction': 4,  # Alternative naming
            'days_late_last_30': 1,
            'Absences': 3,  # Alternative naming
            'SpecialProjectsCount': 2  # Alternative naming
        }
        mixed_df = pd.DataFrame([mixed_data])

        # Should handle mixed naming gracefully
        result = predictor.predict(mixed_df)
        self.assertIn(result, [1, 2, 3, 4])  # Should be a valid score

    def test_rules_based_prediction_with_none_values(self):
        """Test rules_based_prediction with None values in numeric fields."""
        predictor = PerformancePredictor()

        # Create data with None values in numeric fields
        none_data = {
            'engagement_survey': None,
            'emp_satisfaction': None,
            'days_late_last_30': None,
            'absences': None,
            'special_projects_count': None
        }
        none_df = pd.DataFrame([none_data])

        # Should handle None values by using defaults
        result = predictor.rules_based_prediction(none_df)
        # Should return a value based on defaults (all 0s and 3.0)
        self.assertEqual(result, 3)  # Should use defaults and return "Fully Meets"

    def test_rules_based_prediction_with_string_values(self):
        """Test rules_based_prediction with string values that need conversion."""
        predictor = PerformancePredictor()

        # Create data with string values
        string_data = {
            'engagement_survey': '4.0',
            'emp_satisfaction': '4',
            'days_late_last_30': '1',
            'absences': '3',
            'special_projects_count': '2'
        }
        string_df = pd.DataFrame([string_data])

        # Should convert strings to numeric values
        result = predictor.rules_based_prediction(string_df)
        self.assertEqual(result, 4)  # Should still return "Exceeds"

    def test_predict_with_different_input_types(self):
        """Test predict with different input data types."""
        predictor = PerformancePredictor()

        # Test with a list of dictionaries
        list_input = [
            {
                'engagement_survey': 4.0,
                'emp_satisfaction': 4,
                'days_late_last_30': 1,
                'absences': 3,
                'special_projects_count': 2
            }
        ]

        # Should handle list input
        result = predictor.predict(list_input)
        self.assertIn(result, [1, 2, 3, 4])

        # Test with a numpy array if that's supported
        try:
            array_data = np.array([[4.0, 4, 1, 3, 2]])
            column_names = ['engagement_survey', 'emp_satisfaction', 'days_late_last_30',
                            'absences', 'special_projects_count']
            array_df = pd.DataFrame(array_data, columns=column_names)

            result = predictor.predict(array_df)
            self.assertIn(result, [1, 2, 3, 4])
        except:
            # Skip if numpy arrays aren't directly supported
            pass

    def test_rules_based_prediction_borderline_scores(self):
        """Test rules_based_prediction with borderline scores."""
        predictor = PerformancePredictor()

        # Test score exactly at -2 (border between PIP and Needs Improvement)
        borderline_pip = {
            'engagement_survey': 2.5,  # Neutral (0 points)
            'emp_satisfaction': 1,  # -1.5 points
            'days_late_last_30': 3,  # -0.3 points
            'absences': 1,  # -0.2 points
            'special_projects_count': 0  # 0 points
        }
        # Total: 0 - 1.5 - 0.3 - 0.2 + 0 = -2.0
        borderline_pip_df = pd.DataFrame([borderline_pip])

        result = predictor.rules_based_prediction(borderline_pip_df)
        self.assertEqual(result, 1)  # Should be PIP (score is exactly -2)

        # Test score exactly at 0 (border between Needs Improvement and Fully Meets)
        borderline_needs = {
            'engagement_survey': 3.5,  # +1.0 points
            'emp_satisfaction': 3,  # +0.5 points
            'days_late_last_30': 5,  # -0.5 points
            'absences': 5,  # -1.0 points
            'special_projects_count': 0  # 0 points
        }
        # Total: 1.0 + 0.5 - 0.5 - 1.0 + 0 = 0.0
        borderline_needs_df = pd.DataFrame([borderline_needs])

        result = predictor.rules_based_prediction(borderline_needs_df)
        self.assertEqual(result, 3)  # Should be Fully Meets (score is exactly 0)

        # Test score exactly at 2 (border between Fully Meets and Exceeds)
        borderline_meets = {
            'engagement_survey': 5.0,  # +2.5 points
            'emp_satisfaction': 5,  # +2.5 points
            'days_late_last_30': 10,  # -1.0 points
            'absences': 10,  # -2.0 points
            'special_projects_count': 0  # 0 points
        }
        # Total: 2.5 + 2.5 - 1.0 - 2.0 + 0 = 2.0
        borderline_meets_df = pd.DataFrame([borderline_meets])

        result = predictor.rules_based_prediction(borderline_meets_df)
        self.assertEqual(result, 4)  # Should be Exceeds (score is exactly 2)

    def test_rules_based_prediction_exact_boundary_values(self):
        """Test rule-based prediction with scores exactly at the classification boundaries."""
        predictor = PerformancePredictor()

        # Test exactly at the boundary between PIP and Needs Improvement (score = -2)
        boundary_1 = pd.DataFrame([{
            'engagement_survey': 2.0,  # -0.5 points
            'emp_satisfaction': 2,  # -0.5 points
            'days_late_last_30': 5,  # -0.5 points
            'absences': 2,  # -0.4 points
            'special_projects_count': 0  # 0 points
            # Total: -0.5 - 0.5 - 0.5 - 0.4 = -1.9 (just above -2)
        }])

        result = predictor.rules_based_prediction(boundary_1)
        self.assertEqual(result, 2)  # Should be "Needs Improvement"

        # Test exactly at the boundary between Needs Improvement and Fully Meets (score = 0)
        boundary_2 = pd.DataFrame([{
            'engagement_survey': 3.0,  # +0.5 points
            'emp_satisfaction': 3,  # +0.5 points
            'days_late_last_30': 5,  # -0.5 points
            'absences': 2.5,  # -0.5 points
            'special_projects_count': 0  # 0 points
            # Total: 0.5 + 0.5 - 0.5 - 0.5 = 0.0 (exactly at 0)
        }])

        result = predictor.rules_based_prediction(boundary_2)
        self.assertEqual(result, 3)  # Should be "Fully Meets"

    def test_complex_data_format_handling(self):
        """Test handling of complex data formats and conversions."""
        predictor = PerformancePredictor()

        # Test with a mix of data types that need conversion
        mixed_types = pd.DataFrame([{
            'engagement_survey': '4.0',  # String that needs float conversion
            'emp_satisfaction': 4,  # Integer
            'days_late_last_30': 1.5,  # Float for integer field
            'absences': '3.0',  # String that needs float conversion
            'special_projects_count': 2  # Integer
        }])

        result = predictor.predict(mixed_types)
        self.assertIn(result, [1, 2, 3, 4])  # Should handle type conversions

    def test_predict_with_probability_non_integer_prediction(self):
        """Test predict_with_probability with non-integer prediction values."""
        predictor = PerformancePredictor()

        # Mock predict to return non-integer values to test fallback logic
        for unusual_value in [None, 3.5, '3', 0, 5]:
            with patch.object(predictor, 'predict', return_value=unusual_value):
                result = predictor.predict_with_probability(self.employee_df)

                # Should still return a complete result structure
                self.assertIn('prediction', result)
                self.assertIn('prediction_label', result)
                self.assertIn('probabilities', result)

                # Probabilities should still sum to 1
                probs_sum = sum(result['probabilities'].values())
                self.assertAlmostEqual(probs_sum, 1.0, places=1)

    def test_empty_and_null_handling(self):
        """Test handling of empty DataFrames and null values."""
        predictor = PerformancePredictor()

        # Test with empty DataFrame
        empty_df = pd.DataFrame()

        # Should handle empty DataFrame without crashing
        try:
            result = predictor.predict(empty_df)
            # If it returns a value, it should be a valid score
            self.assertIn(result, [1, 2, 3, 4])
        except Exception:
            # If it raises an exception, predict should catch it and return default
            result = predictor.predict(empty_df)
            self.assertEqual(result, 3)  # Default to "Fully Meets"

        # Test with all null values
        null_df = pd.DataFrame([{
            'engagement_survey': None,
            'emp_satisfaction': None,
            'days_late_last_30': None,
            'absences': None,
            'special_projects_count': None
        }])

        # Should handle null values without crashing
        result = predictor.predict(null_df)
        self.assertIn(result, [1, 2, 3, 4])  # Should return a valid score