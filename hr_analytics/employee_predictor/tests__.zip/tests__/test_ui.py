# employee_predictor/tests__/test_ui.py
from django.test import TestCase, Client, LiveServerTestCase
from django.urls import reverse
from django.contrib.auth.models import User
from django.contrib import messages
from decimal import Decimal
from datetime import date, timedelta

from employee_predictor.models import Employee, Attendance, Leave, Payroll
from employee_predictor.tests.test_helper import axes_login

# Try to import BeautifulSoup
try:
    from bs4 import BeautifulSoup

    BS4_AVAILABLE = True
except ImportError:
    BS4_AVAILABLE = False
    print("BeautifulSoup not available. Most UI tests__ will be skipped.")

# Try to import Selenium components
try:
    from selenium import webdriver
    from selenium.webdriver.common.by import By
    from selenium.webdriver.support.ui import WebDriverWait
    from selenium.webdriver.support import expected_conditions as EC
    from selenium.webdriver.common.keys import Keys
    from selenium.webdriver.chrome.options import Options

    SELENIUM_AVAILABLE = True
except ImportError:
    SELENIUM_AVAILABLE = False
    print("Selenium not available. Responsive design tests__ will be skipped.")

# If BeautifulSoup is not available, create a placeholder test
if not BS4_AVAILABLE:
    class UITestsSkipped(TestCase):
        def test_bs4_required(self):
            self.skipTest("BeautifulSoup is required for UI tests__. Install with: pip install beautifulsoup4")
else:
    # UI tests__ that require BeautifulSoup
    class AdminPanelUITest(TestCase):
        def setUp(self):
            # Create staff user
            self.staff_user = User.objects.create_user(
                username='staffuser',
                password='staffpassword',
                email='staff@example.com',
                is_staff=True
            )

            # Create employees for testing
            for i in range(1, 6):
                Employee.objects.create(
                    name=f'Employee {i}',
                    emp_id=f'EMP00{i}',
                    department='IT' if i % 2 == 0 else 'HR',
                    position='Developer' if i % 2 == 0 else 'Manager',
                    date_of_hire=date(2020, 1, i),
                    gender='M' if i % 2 == 0 else 'F',
                    marital_status='Single',
                    salary=Decimal(f'{50000 + i * 5000}.00'),
                    engagement_survey=4.0,
                    emp_satisfaction=4,
                    special_projects_count=i,
                    days_late_last_30=0 if i % 2 == 0 else 1,
                    absences=i - 1
                )

            # Create client
            self.client = Client()

            # Login as staff user
            axes_login(self.client, username='staffuser', password='staffpassword')

        def test_dashboard_functionality(self):
            """Test dashboard displays correct statistics and components"""
            response = self.client.get(reverse('dashboard'))

            # Check status code
            self.assertEqual(response.status_code, 200)

            # Parse HTML content
            soup = BeautifulSoup(response.content, 'html.parser')

            # Look for dashboard by URL rather than title
            self.assertEqual(response.request['PATH_INFO'], '/dashboard/')

            # Check for employee statistics
            page_text = soup.get_text().lower()
            self.assertTrue('employee' in page_text, "No employee statistics found")

            # Check for department information
            self.assertTrue('department' in page_text, "No department information found")

            # Check that employees are being counted
            # This is more flexible than looking for "5" specifically
            self.assertTrue(any(str(i) in page_text for i in range(1, 10)),
                            "No employee count numbers found")

        def test_employee_list_ui(self):
            """Test employee list view UI components"""
            response = self.client.get(reverse('employee-list'))

            # Check status code
            self.assertEqual(response.status_code, 200)

            # Parse HTML
            soup = BeautifulSoup(response.content, 'html.parser')

            # Check for employee table
            table = soup.find('table')
            self.assertIsNotNone(table, "No table found on employee list page")

            # Check for search functionality
            search_inputs = soup.find_all('input')
            search_exists = False
            for input_elem in search_inputs:
                attributes = input_elem.attrs
                if ('name' in attributes and attributes['name'] == 'search') or \
                        ('placeholder' in attributes and 'search' in attributes['placeholder'].lower()):
                    search_exists = True
                    break
            self.assertTrue(search_exists, "No search input found")

            # Check for any add/new/create button or link
            add_btn_found = False

            # Check all links for add-related text
            for a_tag in soup.find_all('a'):
                if a_tag.text and any(term in a_tag.text.lower() for term in ['add', 'new', 'create', '+']):
                    add_btn_found = True
                    break

            # Check all buttons for add-related text
            if not add_btn_found:
                for btn in soup.find_all('button'):
                    if btn.text and any(term in btn.text.lower() for term in ['add', 'new', 'create', '+']):
                        add_btn_found = True
                        break

            # If still not found, check for icon buttons (like a plus icon)
            if not add_btn_found:
                for i_tag in soup.find_all('i'):
                    if i_tag.get('class') and any('plus' in cls or 'add' in cls for cls in i_tag.get('class')):
                        add_btn_found = True
                        break

            self.assertTrue(add_btn_found, "No Add/New/Create Employee button found")

            # Check that employee data is displayed
            page_text = soup.get_text()
            self.assertTrue(any(f"Employee {i}" in page_text for i in range(1, 6)),
                            "No employee data displayed")

        def test_employee_search_filter(self):
            """Test search and filter functionality on employee list"""
            # Test search by name
            response = self.client.get(reverse('employee-list') + '?search=Employee+1')
            soup = BeautifulSoup(response.content, 'html.parser')

            # Check page content for Employee 1
            page_text = soup.get_text()
            self.assertIn('Employee 1', page_text, "Employee 1 not found in search results")

            # Test filter by department
            response = self.client.get(reverse('employee-list') + '?department=IT')
            soup = BeautifulSoup(response.content, 'html.parser')

            # IT department employees (even numbers)
            page_text = soup.get_text()
            self.assertIn('Employee 2', page_text, "IT department employee not found")
            self.assertIn('Employee 4', page_text, "IT department employee not found")

        def test_employee_create_form(self):
            """Test employee creation form UI and validation"""
            # Get the form
            response = self.client.get(reverse('employee-create'))
            self.assertEqual(response.status_code, 200)

            # Check form elements
            soup = BeautifulSoup(response.content, 'html.parser')
            form = soup.find('form')
            self.assertIsNotNone(form, "No form found on create page")

            # Check required fields exist
            required_fields = ['name', 'emp_id', 'department', 'position', 'date_of_hire']
            for field in required_fields:
                field_elem = soup.find(attrs={'name': field})
                self.assertIsNotNone(field_elem, f"Required field {field} not found")

            # Test form submission with invalid data
            response = self.client.post(reverse('employee-create'), {
                'name': '',  # Empty name should fail validation
                'emp_id': 'EMP006',
                'department': 'IT',
                'position': 'Developer',
                'date_of_hire': '2020-01-01',
                'salary': '60000.00',
                'engagement_survey': 4.0,
                'emp_satisfaction': 4,
                'special_projects_count': 2,
                'days_late_last_30': 1,
                'absences': 3
            })

            # Form should display error
            self.assertEqual(response.status_code, 200)  # Returns to form page
            soup = BeautifulSoup(response.content, 'html.parser')

            # Look for any error indicators
            error_elements = soup.find_all(
                class_=lambda c: c and any(term in c for term in ['error', 'invalid', 'danger']))
            self.assertTrue(len(error_elements) > 0, "No error elements found for invalid form")


    class EmployeePortalUITest(TestCase):
        def setUp(self):
            # Create employee user
            self.employee_user = User.objects.create_user(
                username='employeeuser',
                password='employeepassword',
                email='employee@example.com'
            )

            # Create employee record
            self.employee = Employee.objects.create(
                user=self.employee_user,
                name='Test Employee',
                emp_id='EMP001',
                department='IT',
                position='Developer',
                date_of_hire=date(2020, 1, 1),
                gender='M',
                marital_status='Single',
                salary=Decimal('60000.00'),
                engagement_survey=4.0,
                emp_satisfaction=4,
                special_projects_count=2,
                days_late_last_30=1,
                absences=3
            )

            # Create attendance records
            for i in range(5):
                day = date.today() - timedelta(days=i)
                status = 'PRESENT' if i % 4 != 0 else 'ABSENT'  # One absence every 4 days
                Attendance.objects.create(
                    employee=self.employee,
                    date=day,
                    status=status,
                    hours_worked=Decimal('8.00') if status == 'PRESENT' else Decimal('0.00')
                )

            # Create leave record
            self.leave = Leave.objects.create(
                employee=self.employee,
                start_date=date.today() + timedelta(days=5),
                end_date=date.today() + timedelta(days=7),
                leave_type='ANNUAL',
                status='APPROVED',
                reason='Vacation'
            )

            # Create payroll record
            self.payroll = Payroll.objects.create(
                employee=self.employee,
                period_start=date(2023, 1, 1),
                period_end=date(2023, 1, 31),
                basic_salary=Decimal('5000.00'),
                overtime_hours=Decimal('10.00'),
                overtime_rate=Decimal('20.00'),
                bonuses=Decimal('500.00'),
                deductions=Decimal('200.00'),
                tax=Decimal('800.00'),
                net_salary=Decimal('4700.00'),
                status='APPROVED'
            )

            # Create client and login
            self.client = Client()
            axes_login(self.client, username='employeeuser', password='employeepassword')

        def test_employee_dashboard(self):
            """Test employee portal dashboard UI"""
            response = self.client.get(reverse('employee-portal'))
            self.assertEqual(response.status_code, 200)

            soup = BeautifulSoup(response.content, 'html.parser')

            # Check for employee name
            page_text = soup.get_text()
            self.assertIn(self.employee.name, page_text, "Employee name not found on dashboard")

            # Check for attendance information
            attendance_related = soup.find_all(string=lambda text: 'attendance' in text.lower() if text else False)
            self.assertTrue(len(attendance_related) > 0, "No attendance information found")

            # Check for leave information
            leave_related = soup.find_all(string=lambda text: 'leave' in text.lower() if text else False)
            self.assertTrue(len(leave_related) > 0, "No leave information found")

            # Check that upcoming leave is displayed with leave type (ANNUAL) instead of reason
            self.assertIn('ANNUAL', page_text, "Leave type not found on dashboard")

        def test_attendance_list_view(self):
            """Test employee attendance list view"""
            response = self.client.get(reverse('employee-attendance'))
            self.assertEqual(response.status_code, 200)

            soup = BeautifulSoup(response.content, 'html.parser')

            # Check for attendance table
            table = soup.find('table')
            self.assertIsNotNone(table, "No attendance table found")

            # Check if status is displayed
            page_text = soup.get_text()
            self.assertTrue('PRESENT' in page_text or 'Present' in page_text,
                            "Attendance status not found")
            self.assertTrue('ABSENT' in page_text or 'Absent' in page_text,
                            "Attendance status not found")

        def test_leave_application(self):
            """Test leave application process UI"""
            # Check leave list view
            response = self.client.get(reverse('employee-leaves'))
            self.assertEqual(response.status_code, 200)

            soup = BeautifulSoup(response.content, 'html.parser')

            # Check for existing leave with leave type (ANNUAL) instead of reason
            page_text = soup.get_text()
            self.assertIn('ANNUAL', page_text, "Existing leave not found")

            # Check for any button or link to create new leave
            # This could be "New Request", "Apply for Leave", "+ Leave", etc.
            leave_btn_found = False

            # First check for text similar to "New Request"
            for a_tag in soup.find_all('a'):
                if a_tag.text and any(term in a_tag.text.lower() for term in
                                      ['new', 'request', 'apply', 'create', 'add']):
                    leave_btn_found = True
                    break

            # If not found, check buttons
            if not leave_btn_found:
                for btn in soup.find_all('button'):
                    if btn.text and any(term in btn.text.lower() for term in
                                        ['new', 'request', 'apply', 'create', 'add']):
                        leave_btn_found = True
                        break

            # If still not found, check for plus icons
            if not leave_btn_found:
                for i_tag in soup.find_all('i'):
                    if i_tag.get('class') and any('plus' in cls or 'add' in cls for cls in i_tag.get('class')):
                        leave_btn_found = True
                        break

            self.assertTrue(leave_btn_found, "No button/link to create new leave found")

        def test_payslip_viewing(self):
            """Test payslip viewing functionality"""
            # Check payslip list view
            response = self.client.get(reverse('employee-payslips'))
            self.assertEqual(response.status_code, 200)

            soup = BeautifulSoup(response.content, 'html.parser')

            # Check for payroll information
            payroll_text = soup.find_all(string=lambda text: any(term in text.lower() if text else False
                                                                 for term in ['salary', 'payroll', 'payment']))
            self.assertTrue(len(payroll_text) > 0, "No payroll information found")


    class FormValidationUITest(TestCase):
        """Test form validation and error display in UI"""

        def setUp(self):
            # Create staff user
            self.staff_user = User.objects.create_user(
                username='staffuser',
                password='staffpassword',
                is_staff=True
            )

            # Create client and login
            self.client = Client()
            axes_login(self.client, username='staffuser', password='staffpassword')

        def test_employee_form_validation(self):
            """Test employee form validation UI"""
            # Try to submit invalid form (missing required fields)
            response = self.client.post(reverse('employee-create'), {
                'name': '',  # Missing name
                'emp_id': '',  # Missing ID
                'salary': 'invalid',  # Invalid salary format
                'engagement_survey': '10'  # Out of range (1-5)
            })

            # Should stay on same page with errors
            self.assertEqual(response.status_code, 200)

            soup = BeautifulSoup(response.content, 'html.parser')

            # Check for error messages (look for common error indicators)
            error_elements = soup.find_all(
                class_=lambda c: c and any(term in c for term in ['error', 'invalid', 'danger']))
            self.assertTrue(len(error_elements) > 0, "No error elements found for invalid form")

# Only run these tests__ if Selenium is available
if SELENIUM_AVAILABLE and BS4_AVAILABLE:
    class ResponsiveDesignTest(LiveServerTestCase):
        """Test responsive design using Selenium"""

        @classmethod
        def setUpClass(cls):
            super().setUpClass()
            # Set up Chrome options for headless testing
            chrome_options = Options()
            chrome_options.add_argument('--headless')
            chrome_options.add_argument('--no-sandbox')
            chrome_options.add_argument('--disable-dev-shm-usage')

            try:
                # Create WebDriver
                cls.selenium = webdriver.Chrome(options=chrome_options)
                cls.selenium.implicitly_wait(10)
                cls.selenium_works = True
            except:
                cls.selenium_works = False
                print("Chrome WebDriver could not be initialized. Responsive design tests__ will be skipped.")

        @classmethod
        def tearDownClass(cls):
            if hasattr(cls, 'selenium') and cls.selenium_works:
                cls.selenium.quit()
            super().tearDownClass()

        def setUp(self):
            if not hasattr(self.__class__, 'selenium_works') or not self.__class__.selenium_works:
                self.skipTest("Selenium WebDriver is not working properly")

            # Create a staff user
            self.staff_user = User.objects.create_user(
                username='staffuser',
                password='staffpassword',
                is_staff=True
            )

            # Create an employee
            self.employee = Employee.objects.create(
                name='Test Employee',
                emp_id='EMP001',
                department='IT',
                position='Developer',
                date_of_hire=date(2020, 1, 1),
                gender='M',
                marital_status='Single',
                salary=Decimal('60000.00'),
                engagement_survey=4.0,
                emp_satisfaction=4,
                special_projects_count=2,
                days_late_last_30=1,
                absences=3
            )

        def test_responsive_login(self):
            """Test responsive login page at different screen sizes"""
            # Desktop size
            self.selenium.set_window_size(1200, 800)
            self.selenium.get(f'{self.live_server_url}/login/')

            # Check login form is visible
            login_form = self.selenium.find_elements(By.TAG_NAME, 'form')
            self.assertTrue(len(login_form) > 0, "Login form not found")

            # Tablet size
            self.selenium.set_window_size(768, 1024)
            self.selenium.get(f'{self.live_server_url}/login/')

            # Check login form is still visible
            login_form = self.selenium.find_elements(By.TAG_NAME, 'form')
            self.assertTrue(len(login_form) > 0, "Login form not found at tablet size")

            # Mobile size
            self.selenium.set_window_size(375, 667)
            self.selenium.get(f'{self.live_server_url}/login/')

            # Check login form is still visible
            login_form = self.selenium.find_elements(By.TAG_NAME, 'form')
            self.assertTrue(len(login_form) > 0, "Login form not found at mobile size")


class AlternativeUITests(TestCase):
    """UI tests__ that don't depend on external libraries."""

    def setUp(self):
        self.staff_user = User.objects.create_user(
            username='staffuser',
            password='staffpassword',
            is_staff=True
        )
        self.client = Client()
        axes_login(self.client, 'staffuser', 'staffpassword')

    def test_basic_page_content(self):
        """Test basic page content without using BeautifulSoup."""
        response = self.client.get(reverse('dashboard'))
        content = response.content.decode('utf-8')

        # Check for key content using string operations
        self.assertIn('Dashboard', content)
        self.assertIn('Employees', content)


class SimpleUITests(TestCase):
    def setUp(self):
        self.admin_user = User.objects.create_user(
            username='simpleui',
            password='password',
            is_staff=True
        )
        self.client = Client()
        axes_login(self.client, 'simpleui', 'password')

    def test_basic_html_structure(self):
        """Test basic HTML structure without BeautifulSoup."""
        # Test Dashboard
        response = self.client.get(reverse('dashboard'))
        content = response.content.decode('utf-8')

        # Basic checks
        self.assertIn('<html', content)
        self.assertIn('<body', content)
        self.assertIn('Dashboard', content)

        # Test Employee List
        response = self.client.get(reverse('employee-list'))
        content = response.content.decode('utf-8')
        self.assertIn('Employees', content)

        # Test forms
        response = self.client.get(reverse('employee-create'))
        content = response.content.decode('utf-8')
        self.assertIn('<form', content)
        self.assertIn('method="post"', content.lower())