import os
import csv
import tempfile
from datetime import date, timedelta
from decimal import Decimal
from django.test import TestCase
from django.contrib.auth.models import User
from django.core.files.uploadedfile import SimpleUploadedFile
from employee_predictor.models import Employee, Attendance, Leave, Payroll
from employee_predictor.forms import (
    EmployeeForm, LeaveForm, AttendanceForm, PayrollForm,
    BulkAttendanceForm, EmployeeRegistrationForm
)


class EmployeeFormTest(TestCase):
    def test_valid_data(self):
        form_data = {
            'name': 'Test Employee',
            'emp_id': 'EMP001',
            'department': 'IT',
            'position': 'Developer',
            'date_of_hire': '2020-01-01',
            'gender': 'M',
            'marital_status': 'Single',
            'age': 30,
            'race': 'White',
            'hispanic_latino': 'No',
            'recruitment_source': 'LinkedIn',
            'salary': Decimal('60000.00'),
            'engagement_survey': 4.0,
            'emp_satisfaction': 4,
            'special_projects_count': 2,
            'days_late_last_30': 1,
            'absences': 3,
            'performance_score': 'Exceeds',
            'employment_status': 'Active'
        }

        form = EmployeeForm(data=form_data)
        self.assertTrue(form.is_valid())

    def test_invalid_engagement_survey(self):
        form_data = {
            'name': 'Test Employee',
            'emp_id': 'EMP001',
            'department': 'IT',
            'position': 'Developer',
            'date_of_hire': '2020-01-01',
            'gender': 'M',
            'marital_status': 'Single',
            'age': 30,
            'race': 'White',
            'hispanic_latino': 'No',
            'recruitment_source': 'LinkedIn',
            'salary': Decimal('60000.00'),
            'engagement_survey': 6.0,  # Invalid: should be between 1 and 5
            'emp_satisfaction': 4,
            'special_projects_count': 2,
            'days_late_last_30': 1,
            'absences': 3,
            'performance_score': 'Exceeds',
            'employment_status': 'Active'
        }

        form = EmployeeForm(data=form_data)
        self.assertFalse(form.is_valid())
        self.assertIn('engagement_survey', form.errors)

    def test_employee_form_with_unicode_characters(self):
        """Test employee form validation with Unicode characters."""
        # Create a form with Unicode characters in the name
        form_data = {
            'name': '你好世界',  # Unicode characters
            'emp_id': 'EMP123',  # Use a unique ID that doesn't exist yet
            'department': 'IT',
            'position': 'Developer',
            'date_of_hire': '2020-01-01',
            'gender': 'M',
            'marital_status': 'Single',
            'age': 30,
            'salary': '60000.00',
            'engagement_survey': 4.0,
            'emp_satisfaction': 4,
            'special_projects_count': 2,
            'days_late_last_30': 1,
            'absences': 3,
            # Add the missing required fields
            'hispanic_latino': 'No',
            'employment_status': 'Active'
        }

        form = EmployeeForm(data=form_data)

        # If the form should accept Unicode, modify test to expect valid form
        self.assertTrue(form.is_valid(),
                        f"Form should accept Unicode characters. Errors: {form.errors}")

    # NEW TEST: Test days_late_last_30 validation
    def test_invalid_days_late(self):
        """Test validation for days_late_last_30 field."""
        # Test with days_late_last_30 > 30
        form_data = {
            'name': 'Test Employee',
            'emp_id': 'EMP002',
            'department': 'IT',
            'position': 'Developer',
            'date_of_hire': '2020-01-01',
            'gender': 'M',
            'marital_status': 'Single',
            'age': 30,
            'race': 'White',
            'hispanic_latino': 'No',
            'recruitment_source': 'LinkedIn',
            'salary': Decimal('60000.00'),
            'engagement_survey': 4.0,
            'emp_satisfaction': 4,
            'special_projects_count': 2,
            'days_late_last_30': 35,  # Invalid: should be between 0 and 30
            'absences': 3,
            'performance_score': 'Exceeds',
            'employment_status': 'Active'
        }

        form = EmployeeForm(data=form_data)
        self.assertFalse(form.is_valid())
        self.assertIn('days_late_last_30', form.errors)
        self.assertIn('Days late must be between 0 and 30', str(form.errors['days_late_last_30']))

        # Test with days_late_last_30 < 0
        form_data['days_late_last_30'] = -5
        form = EmployeeForm(data=form_data)
        self.assertFalse(form.is_valid())
        self.assertIn('days_late_last_30', form.errors)
        self.assertIn('Days late must be between 0 and 30', str(form.errors['days_late_last_30']))


class LeaveFormTest(TestCase):
    def setUp(self):
        self.employee = Employee.objects.create(
            name='Test Employee',
            emp_id='EMP001',
            department='IT',
            position='Developer',
            date_of_hire=date(2020, 1, 1),
            gender='M',
            marital_status='Single',
            salary=Decimal('60000.00'),
            engagement_survey=4.0,
            emp_satisfaction=4,
            special_projects_count=2,
            days_late_last_30=1,
            absences=3
        )

    def test_valid_leave_request(self):
        form_data = {
            'employee': self.employee.id,
            'start_date': date.today() + timedelta(days=5),
            'end_date': date.today() + timedelta(days=10),
            'leave_type': 'ANNUAL',
            'reason': 'Family vacation'
        }

        form = LeaveForm(data=form_data)
        self.assertTrue(form.is_valid())

    def test_end_date_before_start_date(self):
        form_data = {
            'employee': self.employee.id,
            'start_date': date.today() + timedelta(days=10),
            'end_date': date.today() + timedelta(days=5),  # End date before start date
            'leave_type': 'ANNUAL',
            'reason': 'Family vacation'
        }

        form = LeaveForm(data=form_data)
        self.assertFalse(form.is_valid())

    def test_overlapping_leave(self):
        # Create an existing approved leave
        Leave.objects.create(
            employee=self.employee,
            start_date=date.today() + timedelta(days=5),
            end_date=date.today() + timedelta(days=15),
            leave_type='ANNUAL',
            status='APPROVED',
            reason='Existing leave'
        )

        # Try to create an overlapping leave
        form_data = {
            'employee': self.employee.id,
            'start_date': date.today() + timedelta(days=10),
            'end_date': date.today() + timedelta(days=20),
            'leave_type': 'SICK',
            'reason': 'Overlapping leave'
        }

        form = LeaveForm(data=form_data)
        self.assertFalse(form.is_valid())

    # NEW TEST: Test for overlapping with PENDING status
    def test_overlapping_with_pending_leave(self):
        """Test validation for overlapping with a PENDING leave."""
        # Create an existing pending leave
        Leave.objects.create(
            employee=self.employee,
            start_date=date.today() + timedelta(days=5),
            end_date=date.today() + timedelta(days=15),
            leave_type='ANNUAL',
            status='PENDING',  # PENDING status
            reason='Existing pending leave'
        )

        # Try to create an overlapping leave
        form_data = {
            'employee': self.employee.id,
            'start_date': date.today() + timedelta(days=10),
            'end_date': date.today() + timedelta(days=20),
            'leave_type': 'SICK',
            'reason': 'Overlapping with pending leave'
        }

        form = LeaveForm(data=form_data)
        self.assertFalse(form.is_valid())
        self.assertIn('There is already an active leave request for this period', str(form.errors))

    def test_leave_form_empty_dates(self):
        """Test LeaveForm with empty date fields."""
        form_data = {
            'employee': self.employee.id,
            'leave_type': 'ANNUAL',
            'reason': 'Vacation'
            # Missing start_date and end_date
        }

        form = LeaveForm(data=form_data)
        self.assertFalse(form.is_valid())
        self.assertIn('start_date', form.errors)
        self.assertIn('end_date', form.errors)

    def test_leave_form_with_custom_initial_data(self):
        """Test LeaveForm with custom initial data."""
        # Test initializing the form with initial data
        initial_data = {
            'employee': self.employee,
            'start_date': date.today(),
            'end_date': date.today() + timedelta(days=5),
            'leave_type': 'SICK',
            'reason': 'Initial reason'
        }

        # Initialize form with initial data
        form = LeaveForm(initial=initial_data)

        # Check form has initial values set correctly
        self.assertEqual(form.initial['employee'], self.employee)
        self.assertEqual(form.initial['leave_type'], 'SICK')

        # Now submit with modified data
        form_data = {
            'employee': self.employee.id,
            'start_date': date.today().strftime('%Y-%m-%d'),
            'end_date': (date.today() + timedelta(days=3)).strftime('%Y-%m-%d'),  # Different from initial
            'leave_type': 'ANNUAL',  # Different from initial
            'reason': 'Updated reason'
        }

        form = LeaveForm(data=form_data, initial=initial_data)
        self.assertTrue(form.is_valid())

    # NEW TEST: Test updating an existing leave request to avoid overlap with itself
    def test_update_existing_leave(self):
        """Test updating an existing leave without triggering overlap validation with itself."""
        # Create an existing leave
        existing_leave = Leave.objects.create(
            employee=self.employee,
            start_date=date.today() + timedelta(days=5),
            end_date=date.today() + timedelta(days=15),
            leave_type='ANNUAL',
            status='APPROVED',
            reason='Existing leave'
        )

        # Now update the same leave with modified dates
        form_data = {
            'employee': self.employee.id,
            'start_date': (date.today() + timedelta(days=6)).strftime('%Y-%m-%d'),
            'end_date': (date.today() + timedelta(days=16)).strftime('%Y-%m-%d'),
            'leave_type': 'ANNUAL',
            'reason': 'Updated leave'
        }

        # Create form for updating existing leave
        form = LeaveForm(data=form_data, instance=existing_leave)
        self.assertTrue(form.is_valid(), f"Form should be valid when updating existing leave. Errors: {form.errors}")


class PayrollFormTest(TestCase):
    def setUp(self):
        self.employee = Employee.objects.create(
            name='Payroll Test Employee',
            emp_id='EMP_PAY',
            department='Finance',
            position='Accountant',
            date_of_hire=date(2020, 1, 1),
            gender='F',
            marital_status='Single',
            salary=Decimal('55000.00'),
            engagement_survey=3.5,
            emp_satisfaction=3,
            special_projects_count=1,
            days_late_last_30=0,
            absences=1,
            hispanic_latino='No',
            employment_status='Active'
        )

    def test_payroll_form_validation(self):
        """Test PayrollForm validation methods."""
        # Create valid form data
        form_data = {
            'employee': self.employee.id,
            'period_start': '2023-01-01',
            'period_end': '2023-01-31',
            'basic_salary': '4500.00',
            'overtime_hours': '10.00',
            'overtime_rate': '20.00',
            'bonuses': '500.00',
            'deductions': '200.00',
            'tax': '600.00'
        }

        form = PayrollForm(data=form_data)
        self.assertTrue(form.is_valid())

        # Test end date before start date
        invalid_data = form_data.copy()
        invalid_data['period_end'] = '2022-12-31'  # Before start date
        form = PayrollForm(data=invalid_data)
        self.assertFalse(form.is_valid())
        self.assertIn('End date cannot be before start date', str(form.errors))

        # Test overlapping payroll periods
        # First create an existing payroll
        Payroll.objects.create(
            employee=self.employee,
            period_start=date(2023, 2, 1),
            period_end=date(2023, 2, 28),
            basic_salary=Decimal('4500.00'),
            net_salary=Decimal('4500.00')
        )

        # Try to create one that overlaps
        overlap_data = form_data.copy()
        overlap_data['period_start'] = '2023-02-15'
        overlap_data['period_end'] = '2023-03-15'
        form = PayrollForm(data=overlap_data)
        self.assertFalse(form.is_valid())
        self.assertIn('already a payroll record', str(form.errors))

    def test_payroll_form_with_none_dates(self):
        """Test PayrollForm.clean() with None values for dates."""
        # Create form data with missing dates
        form_data = {
            'employee': self.employee.id,
            'basic_salary': '4500.00',
            'overtime_hours': '10.00',
            'overtime_rate': '20.00',
            'bonuses': '500.00',
            'deductions': '200.00',
            'tax': '600.00'
            # Missing period_start and period_end
        }

        form = PayrollForm(data=form_data)
        self.assertFalse(form.is_valid())
        self.assertIn('period_start', form.errors)
        self.assertIn('period_end', form.errors)

    # NEW TEST: Test updating existing payroll
    def test_update_existing_payroll(self):
        """Test updating an existing payroll record without triggering overlap validation with itself."""
        # Create an existing payroll
        existing_payroll = Payroll.objects.create(
            employee=self.employee,
            period_start=date(2023, 3, 1),
            period_end=date(2023, 3, 31),
            basic_salary=Decimal('4500.00'),
            net_salary=Decimal('4500.00')
        )

        # Update the existing payroll with new values
        form_data = {
            'employee': self.employee.id,
            'period_start': '2023-03-01',
            'period_end': '2023-03-31',
            'basic_salary': '5000.00',  # Changed value
            'overtime_hours': '15.00',
            'overtime_rate': '25.00',
            'bonuses': '600.00',
            'deductions': '250.00',
            'tax': '700.00'
        }

        # Create form for updating existing payroll
        form = PayrollForm(data=form_data, instance=existing_payroll)
        self.assertTrue(form.is_valid(), f"Form should be valid when updating existing payroll. Errors: {form.errors}")


class AttendanceFormTest(TestCase):
    def setUp(self):
        self.employee = Employee.objects.create(
            name='Attendance Test Employee',
            emp_id='EMP_ATT',
            department='IT',
            position='Developer',
            date_of_hire=date(2020, 1, 1),
            gender='M',
            marital_status='Single',
            salary=Decimal('60000.00'),
            engagement_survey=4.0,
            emp_satisfaction=4,
            special_projects_count=2,
            days_late_last_30=1,
            absences=3
        )

    def test_attendance_form_validation(self):
        """Test AttendanceForm validation."""
        # Test with valid data
        form_data = {
            'employee': self.employee.id,
            'date': date.today().strftime('%Y-%m-%d'),
            'status': 'PRESENT',
            'check_in': '09:00',
            'check_out': '17:00',
            'notes': 'Regular day'
        }

        form = AttendanceForm(data=form_data)
        self.assertTrue(form.is_valid())

        # Test with invalid time format
        invalid_time = form_data.copy()
        invalid_time['check_in'] = 'not-a-time'
        form = AttendanceForm(data=invalid_time)
        self.assertFalse(form.is_valid())


class BulkAttendanceFormTest(TestCase):
    def test_bulk_attendance_form_validation(self):
        """Test BulkAttendanceForm validation."""
        # Create CSV content
        csv_content = "employee_id,status,check_in,check_out,notes\nEMP001,PRESENT,09:00,17:00,Test"

        # Create file using SimpleUploadedFile
        csv_file = SimpleUploadedFile(
            name='test.csv',
            content=csv_content.encode('utf-8'),
            content_type='text/csv'
        )

        # Create form with the file
        form_data = {
            'date': date.today().strftime('%Y-%m-%d'),
        }
        form = BulkAttendanceForm(data=form_data, files={'csv_file': csv_file})

        # Print form errors for debugging if needed
        if not form.is_valid():
            print(f"Form errors: {form.errors}")

        self.assertTrue(form.is_valid())

        # Test with missing date
        csv_file2 = SimpleUploadedFile(
            name='test.csv',
            content=csv_content.encode('utf-8'),
            content_type='text/csv'
        )

        form_data = {}  # Missing date
        form = BulkAttendanceForm(data=form_data, files={'csv_file': csv_file2})
        self.assertFalse(form.is_valid())


class EmployeeRegistrationFormTest(TestCase):
    def setUp(self):
        self.employee = Employee.objects.create(
            name='Test Employee',
            emp_id='EMP001',
            department='IT',
            position='Developer',
            date_of_hire=date(2020, 1, 1),
            gender='M',
            marital_status='Single',
            salary=Decimal('60000.00'),
            engagement_survey=4.0,
            emp_satisfaction=4,
            special_projects_count=2,
            days_late_last_30=1,
            absences=3
        )

        self.user = User.objects.create_user(
            username='existinguser',
            password='password123'
        )

    def test_valid_registration(self):
        form_data = {
            'employee_id': 'EMP001',
            'username': 'newuser',
            'password1': 'ComplexPassword123',
            'password2': 'ComplexPassword123'
        }

        form = EmployeeRegistrationForm(data=form_data)
        self.assertTrue(form.is_valid())

    def test_invalid_employee_id(self):
        form_data = {
            'employee_id': 'INVALID',
            'username': 'newuser',
            'password1': 'ComplexPassword123',
            'password2': 'ComplexPassword123'
        }

        form = EmployeeRegistrationForm(data=form_data)
        self.assertFalse(form.is_valid())
        self.assertIn('employee_id', form.errors)

    def test_username_already_exists(self):
        form_data = {
            'employee_id': 'EMP001',
            'username': 'existinguser',  # This username already exists
            'password1': 'ComplexPassword123',
            'password2': 'ComplexPassword123'
        }

        form = EmployeeRegistrationForm(data=form_data)
        self.assertFalse(form.is_valid())
        self.assertIn('username', form.errors)

    def test_passwords_dont_match(self):
        form_data = {
            'employee_id': 'EMP001',
            'username': 'newuser',
            'password1': 'ComplexPassword123',
            'password2': 'DifferentPassword123'
        }

        form = EmployeeRegistrationForm(data=form_data)
        self.assertFalse(form.is_valid())

    def test_employee_form_field_validation(self):
        """Test individual field validations in the employee form."""
        # Create a form with invalid salary to trigger the specific error we want
        form_data = {
            'name': 'Test Employee Form Validation',
            'emp_id': 'EMP789',  # Use a unique ID that doesn't exist yet
            'department': 'IT',
            'position': 'Developer',
            'date_of_hire': '2020-01-01',
            'gender': 'M',
            'marital_status': 'Single',
            'age': 30,
            'salary': 'invalid',  # This should cause a salary validation error
            'engagement_survey': 4.0,
            'emp_satisfaction': 4,
            'special_projects_count': 2,
            'days_late_last_30': 1,
            'absences': 3,
            # Add the missing required fields
            'hispanic_latino': 'No',
            'employment_status': 'Active'
        }

        form = EmployeeForm(data=form_data)
        self.assertFalse(form.is_valid())
        self.assertIn('salary', form.errors,
                      f"Expected 'salary' field to have validation errors but got: {form.errors}")

    def test_employee_registration_form_with_linked_employee(self):
        """Test EmployeeRegistrationForm with an employee that already has a user."""
        # First, link a user to the employee
        user = User.objects.create_user(
            username='linkeduser',
            password='password123'
        )
        self.employee.user = user
        self.employee.save()

        # Now try to register with this employee_id
        form_data = {
            'employee_id': self.employee.emp_id,
            'username': 'newuser',
            'password1': 'ComplexPassword123',
            'password2': 'ComplexPassword123'
        }

        form = EmployeeRegistrationForm(data=form_data)
        self.assertFalse(form.is_valid())
        self.assertIn('employee_id', form.errors)
        self.assertIn('already registered', str(form.errors['employee_id']))

        # Clean up - unlink the user
        self.employee.user = None
        self.employee.save()

    def test_employee_form_with_invalid_satisfaction_score(self):
        """Test EmployeeForm with invalid satisfaction score."""
        form_data = {
            'name': 'Test Employee',
            'emp_id': 'EMP789',
            'department': 'IT',
            'position': 'Developer',
            'date_of_hire': '2020-01-01',
            'gender': 'M',
            'marital_status': 'Single',
            'age': 30,
            'race': 'White',
            'hispanic_latino': 'No',
            'recruitment_source': 'LinkedIn',
            'salary': '60000.00',
            'engagement_survey': 4.0,
            'emp_satisfaction': 0,  # Invalid: should be between 1 and 5
            'special_projects_count': 2,
            'days_late_last_30': 1,
            'absences': 3,
            'employment_status': 'Active'
        }

        form = EmployeeForm(data=form_data)
        self.assertFalse(form.is_valid())
        self.assertIn('emp_satisfaction', form.errors)
        self.assertIn('must be between 1 and 5', str(form.errors['emp_satisfaction']))