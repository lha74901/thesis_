# employee_predictor/tests__/test_ml.py
import os
import tempfile
from unittest import mock

import pandas as pd
import numpy as np
from django.test import TestCase
from django.conf import settings
from datetime import date
from decimal import Decimal

from employee_predictor.models import Employee
from employee_predictor.ml.feature_engineering import prepare_data_for_prediction, engineer_features
from employee_predictor.ml.predictor import PerformancePredictor


class FeatureEngineeringTest(TestCase):
    def setUp(self):
        # Create a test employee
        self.employee_data = {
            'emp_id': ['EMP001'],
            'name': ['Test Employee'],
            'date_of_hire': [date(2020, 1, 1)],
            'department': ['IT'],
            'position': ['Developer'],
            'gender': ['M'],
            'marital_status': ['Single'],
            'age': [30],
            'race': ['White'],
            'hispanic_latino': ['No'],
            'recruitment_source': ['LinkedIn'],
            'salary': [60000.00],
            'engagement_survey': [4.0],
            'emp_satisfaction': [4],
            'special_projects_count': [2],
            'days_late_last_30': [1],
            'absences': [3],
            'employment_status': ['Active']
        }

    def test_engineer_features(self):
        # This test will skip actual preprocessing if model/preprocessor is not available
        # It will still test the function call works without errors
        try:
            features = engineer_features(self.employee_data)
            # This might fail if model/preprocessor not available, which is fine
        except ValueError as e:
            if "Preprocessor not found" in str(e):
                # This is expected if testing without ML models
                self.skipTest("Preprocessor not found - skipping feature engineering test")
            else:
                # Other errors should still fail the test
                raise


class PerformancePredictorTest(TestCase):
    def setUp(self):
        # Create a test employee
        self.employee = Employee.objects.create(
            name='Test Employee',
            emp_id='EMP001',
            department='IT',
            position='Developer',
            date_of_hire=date(2020, 1, 1),
            gender='M',
            marital_status='Single',
            age=30,
            race='White',
            hispanic_latino='No',
            recruitment_source='LinkedIn',
            salary=Decimal('60000.00'),
            engagement_survey=4.0,
            emp_satisfaction=4,
            special_projects_count=2,
            days_late_last_30=1,
            absences=3
        )

        # Prepare employee data for prediction
        self.employee_data = {
            'emp_id': [self.employee.emp_id],
            'name': [self.employee.name],
            'date_of_hire': [self.employee.date_of_hire],
            'department': [self.employee.department],
            'position': [self.employee.position],
            'gender': [self.employee.gender],
            'marital_status': [self.employee.marital_status],
            'age': [self.employee.age],
            'race': [self.employee.race],
            'hispanic_latino': [self.employee.hispanic_latino],
            'recruitment_source': [self.employee.recruitment_source],
            'salary': [float(self.employee.salary)],
            'engagement_survey': [self.employee.engagement_survey],
            'emp_satisfaction': [self.employee.emp_satisfaction],
            'special_projects_count': [self.employee.special_projects_count],
            'days_late_last_30': [self.employee.days_late_last_30],
            'absences': [self.employee.absences],
            'employment_status': [self.employee.employment_status]
        }

    def test_rules_based_prediction(self):
        predictor = PerformancePredictor()

        # Test with employee data
        df = pd.DataFrame(self.employee_data)
        prediction = predictor.rules_based_prediction(df)

        # Check that prediction is within expected range (1-4)
        self.assertIn(prediction, [1, 2, 3, 4])

    def test_prediction_with_probability(self):
        predictor = PerformancePredictor()

        # Test with employee data
        result = predictor.predict_with_probability(self.employee_data)

        # Check result structure
        self.assertIn('prediction', result)
        self.assertIn('prediction_label', result)
        self.assertIn('probabilities', result)

        # Check that prediction is within expected range (1-4)
        self.assertIn(result['prediction'], [1, 2, 3, 4])

        # Check that probabilities sum to approximately 1
        probabilities_sum = sum(result['probabilities'].values())
        self.assertAlmostEqual(probabilities_sum, 1.0, places=1)


class ComprehensiveMLPredictorTest(TestCase):
    def setUp(self):
        self.employee_data = {
            'emp_id': ['EMP001'],
            'name': ['Test Employee'],
            'date_of_hire': [date(2020, 1, 1)],
            'department': ['IT'],
            'position': ['Developer'],
            'gender': ['M'],
            'marital_status': ['Single'],
            'age': [30],
            'salary': [60000.00],
            'engagement_survey': [4.0],
            'emp_satisfaction': [4],
            'special_projects_count': [2],
            'days_late_last_30': [1],
            'absences': [3],
            'employment_status': ['Active']
        }

    @mock.patch('os.path.exists', return_value=True)
    @mock.patch('joblib.load')
    def test_model_loading_exception_detailed(self, mock_load, mock_exists):
        """Test model loading with specific exceptions."""
        # Test with FileNotFoundError
        mock_load.side_effect = FileNotFoundError("Model file not found")

        predictor = PerformancePredictor()
        self.assertIsNone(predictor.model)

        # Test with OSError
        mock_load.side_effect = OSError("Permission denied")

        predictor = PerformancePredictor()
        self.assertIsNone(predictor.model)

    def test_extreme_values_prediction(self):
        """Test prediction with extreme values."""
        predictor = PerformancePredictor()

        # Test with extremely high values
        high_data = pd.DataFrame({
            'engagement_survey': [5.0],
            'emp_satisfaction': [5],
            'days_late_last_30': [0],
            'absences': [0],
            'special_projects_count': [10]
        })

        high_result = predictor.predict(high_data)
        self.assertEqual(high_result, 4)  # Should be "Exceeds"

        # Test with extremely low values
        low_data = pd.DataFrame({
            'engagement_survey': [1.0],
            'emp_satisfaction': [1],
            'days_late_last_30': [30],
            'absences': [30],
            'special_projects_count': [0]
        })

        low_result = predictor.predict(low_data)
        self.assertEqual(low_result, 1)  # Should be "PIP"


# Add to test_ml.py
class PredictorEdgeCaseTests(TestCase):
    def setUp(self):
        # Create a predictor instance
        self.predictor = PerformancePredictor()

        # Sample employee data with extreme values
        self.high_data = pd.DataFrame({
            'engagement_survey': [5.0],
            'emp_satisfaction': [5],
            'days_late_last_30': [0],
            'absences': [0],
            'special_projects_count': [10]
        })

        self.low_data = pd.DataFrame({
            'engagement_survey': [1.0],
            'emp_satisfaction': [1],
            'days_late_last_30': [30],
            'absences': [30],
            'special_projects_count': [0]
        })

    def test_extreme_values_prediction(self):
        """Test prediction with extreme values."""
        # Test high values (should be "Exceeds")
        result = self.predictor.predict(self.high_data)
        self.assertEqual(result, 4)

        # Test low values (should be "PIP")
        result = self.predictor.predict(self.low_data)
        self.assertEqual(result, 1)

    def test_predict_with_probability_edge_cases(self):
        """Test predict_with_probability with edge cases."""
        # Test with non-standard prediction value
        with mock.patch.object(self.predictor, 'predict', return_value=999):
            result = self.predictor.predict_with_probability(self.high_data)
            self.assertEqual(result['prediction'], 999)
            self.assertEqual(result['prediction_label'], 'Unknown')

            # Probabilities should still add up to 1
            prob_sum = sum(result['probabilities'].values())
            self.assertAlmostEqual(prob_sum, 1.0, places=1)

    def test_predict_with_none_model(self):
        """Test prediction when model is None."""
        predictor = PerformancePredictor()
        predictor.model = None  # Force model to be None

        # Should use rules-based prediction
        result = predictor.predict(pd.DataFrame({'engagement_survey': [4.0]}))
        self.assertIn(result, [1, 2, 3, 4])

    def test_prediction_with_invalid_result(self):
        """Test handling of invalid prediction results."""
        predictor = PerformancePredictor()

        # Create malformed data that might cause issues
        data = pd.DataFrame({
            'engagement_survey': [None],
            'emp_satisfaction': [None],
            'days_late_last_30': [None],
            'absences': [None],
            'special_projects_count': [None]
        })

        # Should still return valid result
        result = predictor.predict(data)
        self.assertIn(result, [1, 2, 3, 4])