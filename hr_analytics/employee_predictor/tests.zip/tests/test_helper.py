# employee_predictor/tests/test_helper.py
from django.test import RequestFactory
from django.contrib.auth import authenticate, login

def axes_login(client, username, password):
    """Login method that works with django-axes by providing a request object."""
    request_factory = RequestFactory()
    request = request_factory.get('/')
    request.session = client.session
    user = authenticate(request=request, username=username, password=password)
    if user:
        # Manually set session auth without going through login flow
        # which would try to call authenticate again
        client.force_login(user)
        return True
    return False
