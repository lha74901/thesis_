# employee_predictor/tests/test_performance.py
import time
import gc
import os
from functools import wraps
import random
from datetime import date, timedelta
from decimal import Decimal
import resource
import logging
from unittest import skipIf

from django.test import TestCase, Client, override_settings
from django.urls import reverse
from django.contrib.auth.models import User
from django.db import connection, reset_queries
from django.conf import settings
from django.core.paginator import Paginator
from django.db.models import Count, Q
from django.core.cache import cache
from django.utils import timezone

from employee_predictor.models import Employee, Attendance, Leave, Payroll
from employee_predictor.tests.test_helper import axes_login
# Check if Debug Toolbar is installed and available
try:
    import debug_toolbar

    DEBUG_TOOLBAR_AVAILABLE = True
except ImportError:
    DEBUG_TOOLBAR_AVAILABLE = False
    print("Django Debug Toolbar not installed. Some performance tests will be skipped.")

# Set up logging
logger = logging.getLogger(__name__)


# Function decorators to help with performance testing
def count_queries(func):
    """Count and log the number of database queries executed during the function."""

    @wraps(func)
    def wrapper(*args, **kwargs):
        reset_queries()
        settings.DEBUG = True  # Required to count queries
        start = time.time()

        result = func(*args, **kwargs)

        end = time.time()
        query_count = len(connection.queries)
        query_time = sum(float(query.get('time', 0)) for query in connection.queries)

        print(f"Function: {func.__name__}")
        print(f"Number of queries: {query_count}")
        print(f"Time spent on queries: {query_time:.4f} seconds")
        print(f"Total execution time: {end - start:.4f} seconds")

        settings.DEBUG = False
        return result

    return wrapper


def measure_time(func):
    """Measure and log the execution time of a function."""

    @wraps(func)
    def wrapper(*args, **kwargs):
        start = time.time()
        result = func(*args, **kwargs)
        end = time.time()

        print(f"Function: {func.__name__}")
        print(f"Execution time: {end - start:.4f} seconds")

        return result

    return wrapper


def measure_memory(func):
    """Measure and log the memory usage of a function."""

    @wraps(func)
    def wrapper(*args, **kwargs):
        # Force garbage collection before measuring
        gc.collect()

        # Get initial memory usage
        initial_usage = resource.getrusage(resource.RUSAGE_SELF).ru_maxrss

        result = func(*args, **kwargs)

        # Force garbage collection again
        gc.collect()

        # Get final memory usage
        final_usage = resource.getrusage(resource.RUSAGE_SELF).ru_maxrss

        # Convert to a more readable format (MB)
        initial_mb = initial_usage / 1024
        final_mb = final_usage / 1024
        diff_mb = (final_usage - initial_usage) / 1024

        print(f"Function: {func.__name__}")
        print(f"Initial memory usage: {initial_mb:.2f} MB")
        print(f"Final memory usage: {final_mb:.2f} MB")
        print(f"Memory usage difference: {diff_mb:.2f} MB")

        return result

    return wrapper


class TestDataMixin:
    """Mixin to generate test data for performance testing."""

    def generate_test_employees(self, count=100):
        """Generate a specified number of test employees."""
        departments = ['IT', 'HR', 'Finance', 'Marketing', 'Sales', 'Operations']
        positions = ['Manager', 'Developer', 'Analyst', 'Specialist', 'Coordinator', 'Assistant']
        genders = ['M', 'F']
        marital_statuses = ['Single', 'Married', 'Divorced', 'Separated', 'Widowed']
        races = ['White', 'Black', 'Asian', 'Hispanic', 'Other']

        employees = []
        for i in range(count):
            employee = Employee(
                name=f'Test Employee {i + 1}',
                emp_id=f'EMP{i + 1:04d}',
                department=random.choice(departments),
                position=random.choice(positions),
                date_of_hire=date(2015, 1, 1) + timedelta(days=random.randint(0, 1825)),  # Within last 5 years
                gender=random.choice(genders),
                marital_status=random.choice(marital_statuses),
                age=random.randint(22, 65),
                race=random.choice(races),
                hispanic_latino=random.choice(['Yes', 'No']),
                recruitment_source=random.choice(['LinkedIn', 'Indeed', 'Referral', 'Agency', 'Other']),
                salary=Decimal(random.randint(30000, 120000)),
                engagement_survey=round(random.uniform(1.0, 5.0), 1),
                emp_satisfaction=random.randint(1, 5),
                special_projects_count=random.randint(0, 10),
                days_late_last_30=random.randint(0, 10),
                absences=random.randint(0, 15)
            )
            employees.append(employee)

        # Bulk create for efficiency
        Employee.objects.bulk_create(employees)
        return employees

    def generate_test_attendance(self, employees, days=30):
        """Generate attendance records for employees over a specified number of days."""
        statuses = ['PRESENT', 'ABSENT', 'LATE', 'ON_LEAVE']
        weights = [0.85, 0.05, 0.05, 0.05]  # Probabilities for each status

        attendance_records = []

        for employee in employees:
            for day in range(days):
                current_date = date.today() - timedelta(days=day)

                # Skip weekends
                if current_date.weekday() >= 5:
                    continue

                # Randomly determine status based on weights
                status = random.choices(statuses, weights=weights)[0]

                # Hours worked depends on status
                if status == 'PRESENT':
                    hours_worked = Decimal(str(random.uniform(7.5, 9.0)))
                elif status == 'LATE':
                    hours_worked = Decimal(str(random.uniform(4.0, 7.0)))
                else:
                    hours_worked = Decimal('0.00')

                attendance = Attendance(
                    employee=employee,
                    date=current_date,
                    status=status,
                    hours_worked=hours_worked,
                    notes=f"Automatically generated for performance testing"
                )
                attendance_records.append(attendance)

                # To avoid memory issues, batch create records
                if len(attendance_records) >= 1000:
                    Attendance.objects.bulk_create(attendance_records)
                    attendance_records = []

        # Create any remaining records
        if attendance_records:
            Attendance.objects.bulk_create(attendance_records)

    def generate_test_leaves(self, employees, count_per_employee=3):
        """Generate leave records for employees."""
        leave_types = ['ANNUAL', 'SICK', 'UNPAID', 'OTHER']
        statuses = ['PENDING', 'APPROVED', 'REJECTED']

        leaves = []
        for employee in employees:
            for _ in range(count_per_employee):
                start_date = date.today() + timedelta(days=random.randint(1, 60))
                end_date = start_date + timedelta(days=random.randint(1, 5))

                leave = Leave(
                    employee=employee,
                    start_date=start_date,
                    end_date=end_date,
                    leave_type=random.choice(leave_types),
                    status=random.choice(statuses),
                    reason=f"Performance testing leave request"
                )
                leaves.append(leave)

        Leave.objects.bulk_create(leaves)

    def generate_test_payrolls(self, employees, months=3):
        """Generate payroll records for employees."""
        payrolls = []

        for month in range(months):
            month_start = date(2023, 1 + month, 1)
            if month == 11:  # Handle December
                month_end = date(2023, 12, 31)
            else:
                month_end = date(2023, 2 + month, 1) - timedelta(days=1)

            for employee in employees:
                base_salary = float(employee.salary) / 12  # Monthly base salary

                payroll = Payroll(
                    employee=employee,
                    period_start=month_start,
                    period_end=month_end,
                    basic_salary=Decimal(str(base_salary)),
                    overtime_hours=Decimal(str(random.uniform(0, 20))),
                    overtime_rate=Decimal('20.00'),
                    bonuses=Decimal(str(random.uniform(0, 1000))),
                    deductions=Decimal(str(random.uniform(100, 500))),
                    tax=Decimal(str(base_salary * 0.2)),  # 20% tax rate
                    net_salary=Decimal('0.00'),  # Will be calculated on save
                    status=random.choice(['DRAFT', 'APPROVED', 'PAID'])
                )
                payrolls.append(payroll)

        Payroll.objects.bulk_create(payrolls)


# Database Query Profiling Tests
class DatabaseQueryProfilingTest(TestCase, TestDataMixin):
    """Test the efficiency of database queries in the application."""

    @classmethod
    def setUpTestData(cls):
        # Create test data - use a smaller dataset for these tests
        cls.admin_user = User.objects.create_user(
            username='admin',
            password='password',
            is_staff=True,
            is_superuser=True
        )

        # Create a moderate number of employees for query testing
        cls.employees = cls.generate_test_employees(cls, count=20)

        # Generate attendance data
        cls.generate_test_attendance(cls, cls.employees, days=30)

        # Generate leave data
        cls.generate_test_leaves(cls, cls.employees)

        # Generate payroll data
        cls.generate_test_payrolls(cls, cls.employees)

    def setUp(self):
        self.client = Client()
        axes_login(self.client, username='admin', password='password')

    @skipIf(not DEBUG_TOOLBAR_AVAILABLE, "Django Debug Toolbar not installed")
    def test_debug_toolbar_configuration(self):
        """Test that Django Debug Toolbar is properly configured."""
        # Check debug toolbar middleware is installed
        self.assertIn('debug_toolbar.middleware.DebugToolbarMiddleware', settings.MIDDLEWARE)

        # Check debug toolbar is in INSTALLED_APPS
        self.assertIn('debug_toolbar', settings.INSTALLED_APPS)

        print("Django Debug Toolbar is properly configured.")

    @count_queries
    def test_employee_list_query_count(self):
        """Test query count for employee list view."""
        response = self.client.get(reverse('employee-list'))
        self.assertEqual(response.status_code, 200)

    @count_queries
    def test_dashboard_query_count(self):
        """Test query count for dashboard view."""
        response = self.client.get(reverse('dashboard'))
        self.assertEqual(response.status_code, 200)

    @count_queries
    def test_employee_detail_query_count(self):
        """Test query count for employee detail view."""
        employee = Employee.objects.first()
        response = self.client.get(reverse('employee-detail', args=[employee.id]))
        self.assertEqual(response.status_code, 200)

    @count_queries
    def test_attendance_list_query_count(self):
        """Test query count for attendance list view."""
        response = self.client.get(reverse('attendance-list'))
        self.assertEqual(response.status_code, 200)

    @count_queries
    def test_leave_list_query_count(self):
        """Test query count for leave list view."""
        response = self.client.get(reverse('leave-list'))
        self.assertEqual(response.status_code, 200)

    @count_queries
    def test_payroll_list_query_count(self):
        """Test query count for payroll list view."""
        response = self.client.get(reverse('payroll-list'))
        self.assertEqual(response.status_code, 200)

    @count_queries
    def test_employee_filtered_query_count(self):
        """Test query count for employee list with filters."""
        # Test with department filter
        response = self.client.get(reverse('employee-list') + '?department=IT')
        self.assertEqual(response.status_code, 200)

    @count_queries
    def test_n_plus_one_detection(self):
        """Test for potential N+1 query patterns in the application."""
        # Test employee list with related data
        with self.assertNumQueries(5):  # Adjust this number based on expected query count
            # This should ideally be 1 query for employees + 1 for pagination = 2
            # If it's significantly more, there might be an N+1 issue
            response = self.client.get(reverse('employee-list'))
            self.assertEqual(response.status_code, 200)


# Page Load Optimization Tests
class PageLoadOptimizationTest(TestCase, TestDataMixin):
    """Test page load performance."""

    @classmethod
    def setUpTestData(cls):
        # Create admin user
        cls.admin_user = User.objects.create_user(
            username='admin',
            password='password',
            is_staff=True,
            is_superuser=True
        )

        # Create test data
        cls.employees = cls.generate_test_employees(cls, count=50)
        cls.generate_test_attendance(cls, cls.employees, days=30)
        cls.generate_test_leaves(cls, cls.employees)
        cls.generate_test_payrolls(cls, cls.employees)

    def setUp(self):
        self.client = Client()
        axes_login(self.client, username='admin', password='password')

        # Clear the cache before each test
        cache.clear()

    @measure_time
    def test_dashboard_load_time(self):
        """Measure dashboard page load time."""
        start_time = time.time()
        response = self.client.get(reverse('dashboard'))
        load_time = time.time() - start_time

        self.assertEqual(response.status_code, 200)
        print(f"Dashboard load time: {load_time:.4f} seconds")

        # Check if load time is within acceptable limits
        self.assertLess(load_time, 1.0, "Dashboard load time exceeds 1 second")

    @measure_time
    def test_employee_list_load_time(self):
        """Measure employee list page load time."""
        start_time = time.time()
        response = self.client.get(reverse('employee-list'))
        load_time = time.time() - start_time

        self.assertEqual(response.status_code, 200)
        print(f"Employee list load time: {load_time:.4f} seconds")

        # Check if load time is within acceptable limits
        self.assertLess(load_time, 1.0, "Employee list load time exceeds 1 second")

    @measure_time
    def test_employee_detail_load_time(self):
        """Measure employee detail page load time."""
        employee = Employee.objects.first()

        start_time = time.time()
        response = self.client.get(reverse('employee-detail', args=[employee.id]))
        load_time = time.time() - start_time

        self.assertEqual(response.status_code, 200)
        print(f"Employee detail load time: {load_time:.4f} seconds")

        # Check if load time is within acceptable limits
        self.assertLess(load_time, 0.5, "Employee detail load time exceeds 0.5 seconds")

    @measure_time
    def test_attendance_list_load_time(self):
        """Measure attendance list page load time."""
        start_time = time.time()
        response = self.client.get(reverse('attendance-list'))
        load_time = time.time() - start_time

        self.assertEqual(response.status_code, 200)
        print(f"Attendance list load time: {load_time:.4f} seconds")

        # Check if load time is within acceptable limits
        self.assertLess(load_time, 1.0, "Attendance list load time exceeds 1 second")

    @measure_time
    def test_repeated_page_load(self):
        """Test if repeated page loads benefit from caching."""
        # First load
        start_time = time.time()
        self.client.get(reverse('dashboard'))
        first_load_time = time.time() - start_time

        # Second load
        start_time = time.time()
        self.client.get(reverse('dashboard'))
        second_load_time = time.time() - start_time

        print(f"First dashboard load: {first_load_time:.4f} seconds")
        print(f"Second dashboard load: {second_load_time:.4f} seconds")

        # If caching is working, second load should be faster
        # but this might not always be true depending on the caching strategy
        if second_load_time > first_load_time * 1.5:
            print("WARNING: Second page load was not faster. Caching might not be effective.")


# Scalability Testing
class ScalabilityTest(TestCase, TestDataMixin):
    """Test application performance with large datasets."""

    @classmethod
    def setUpTestData(cls):
        # Create admin user
        cls.admin_user = User.objects.create_user(
            username='admin',
            password='password',
            is_staff=True,
            is_superuser=True
        )

    def setUp(self):
        self.client = Client()
        axes_login(self.client, username='admin', password='password')

    @measure_time
    @measure_memory
    def test_large_employee_dataset(self):
        """Test application performance with a large employee dataset."""
        # Generate a large number of employees
        try:
            # Determine the size based on available system resources
            # Using a smaller number for CI environments
            if os.environ.get('CI'):
                employee_count = 200
            else:
                employee_count = 1000

            print(f"Generating {employee_count} employees...")
            employees = self.generate_test_employees(count=employee_count)

            print(f"Accessing employee list view...")
            start_time = time.time()
            response = self.client.get(reverse('employee-list'))
            load_time = time.time() - start_time

            self.assertEqual(response.status_code, 200)
            print(f"Employee list load time with {employee_count} employees: {load_time:.4f} seconds")

            # Check pagination
            if hasattr(response.context, 'paginator'):
                paginator = response.context['paginator']
                print(f"Pagination info: {paginator.count} items, {paginator.num_pages} pages")

                # Test accessing different pages
                page_times = []
                for page in range(1, min(4, paginator.num_pages + 1)):
                    start_time = time.time()
                    response = self.client.get(reverse('employee-list') + f'?page={page}')
                    page_time = time.time() - start_time
                    page_times.append(page_time)
                    print(f"Page {page} load time: {page_time:.4f} seconds")

                # Check if page access times are consistent
                if page_times:
                    avg_time = sum(page_times) / len(page_times)
                    max_time = max(page_times)
                    self.assertLess(max_time, avg_time * 2,
                                    "Some pages take significantly longer to load than others")
        except MemoryError:
            self.skipTest("Not enough memory to complete this test")

    @measure_time
    @measure_memory
    def test_large_attendance_dataset(self):
        """Test application performance with a large attendance dataset."""
        try:
            # Create a moderate number of employees
            employee_count = 50
            employees = self.generate_test_employees(count=employee_count)

            # Create a large number of attendance records
            days = 90  # 3 months of attendance data
            print(f"Generating attendance data for {employee_count} employees over {days} days...")
            self.generate_test_attendance(employees, days=days)

            # Calculate expected record count (excluding weekends)
            weekdays = sum(1 for day in range(days) if (date.today() - timedelta(days=day)).weekday() < 5)
            expected_records = employee_count * weekdays

            print(f"Expected attendance records: {expected_records}")
            actual_records = Attendance.objects.count()
            print(f"Actual attendance records: {actual_records}")

            # Test attendance list view
            print(f"Accessing attendance list view...")
            start_time = time.time()
            response = self.client.get(reverse('attendance-list'))
            load_time = time.time() - start_time

            self.assertEqual(response.status_code, 200)
            print(f"Attendance list load time with {actual_records} records: {load_time:.4f} seconds")

        except MemoryError:
            self.skipTest("Not enough memory to complete this test")

    @measure_time
    def test_employee_search_performance(self):
        """Test search performance with large dataset."""
        # Generate test data
        employee_count = 500
        self.generate_test_employees(count=employee_count)

        # Perform search operation
        start_time = time.time()
        response = self.client.get(reverse('employee-list') + '?search=Employee')
        search_time = time.time() - start_time

        self.assertEqual(response.status_code, 200)
        print(f"Search operation time: {search_time:.4f} seconds")

        # Check if search time is within acceptable limits
        self.assertLess(search_time, 2.0, "Search operation exceeds 2 seconds")

    @measure_time
    def test_filtered_query_performance(self):
        """Test performance of filtered queries with large dataset."""
        # Generate test data with known departments
        employee_count = 500
        employees = []
        for i in range(employee_count):
            dept = 'IT' if i % 5 == 0 else 'HR' if i % 5 == 1 else 'Finance' if i % 5 == 2 else 'Marketing' if i % 5 == 3 else 'Sales'
            employee = Employee(
                name=f'Test Employee {i + 1}',
                emp_id=f'EMP{i + 1:04d}',
                department=dept,
                position='Analyst',
                date_of_hire=date(2015, 1, 1) + timedelta(days=i % 1825),
                gender='M' if i % 2 == 0 else 'F',
                marital_status='Single',
                salary=Decimal('60000.00'),
                engagement_survey=4.0,
                emp_satisfaction=4,
                special_projects_count=i % 10,
                days_late_last_30=i % 5,
                absences=i % 15
            )
            employees.append(employee)

        Employee.objects.bulk_create(employees)

        # Test department filter
        start_time = time.time()
        response = self.client.get(reverse('employee-list') + '?department=IT')
        filter_time = time.time() - start_time

        self.assertEqual(response.status_code, 200)
        print(f"Department filter query time: {filter_time:.4f} seconds")

        # Test combined filters
        start_time = time.time()
        response = self.client.get(reverse('employee-list') + '?department=IT&search=Employee')
        combined_filter_time = time.time() - start_time

        self.assertEqual(response.status_code, 200)
        print(f"Combined filter query time: {combined_filter_time:.4f} seconds")

        # Both should be within acceptable limits
        self.assertLess(filter_time, 1.0, "Department filter query exceeds 1 second")
        self.assertLess(combined_filter_time, 1.5, "Combined filter query exceeds 1.5 seconds")


# Index performance tests
class IndexPerformanceTest(TestCase):
    """Test query performance with and without indexes."""

    @classmethod
    def setUpTestData(cls):
        # Create admin user
        cls.admin_user = User.objects.create_user(
            username='admin',
            password='password',
            is_staff=True,
            is_superuser=True
        )

        # Create test data
        departments = ['IT', 'HR', 'Finance', 'Marketing', 'Sales']

        # Create a reasonable number of employees for index testing
        employees = []
        for i in range(1000):
            employee = Employee(
                name=f'Test Employee {i + 1}',
                emp_id=f'EMP{i + 1:04d}',
                department=departments[i % len(departments)],
                position='Analyst',
                date_of_hire=date(2015, 1, 1) + timedelta(days=i % 1825),
                gender='M' if i % 2 == 0 else 'F',
                marital_status='Single',
                salary=Decimal('60000.00'),
                engagement_survey=4.0,
                emp_satisfaction=4,
                special_projects_count=i % 10,
                days_late_last_30=i % 5,
                absences=i % 15
            )
            employees.append(employee)

        Employee.objects.bulk_create(employees)

    def setUp(self):
        self.client = Client()
        axes_login(self.client, username='admin', password='password')

    def test_index_on_emp_id(self):
        """Test query performance with emp_id field."""
        # Ideally, emp_id should be indexed as it's used for lookups

        # Query by emp_id (should be fast if indexed)
        emp_id = 'EMP0500'  # Middle of the dataset

        reset_queries()
        settings.DEBUG = True

        start_time = time.time()
        employee = Employee.objects.filter(emp_id=emp_id).first()
        query_time = time.time() - start_time

        self.assertIsNotNone(employee)
        print(f"Query time for emp_id lookup: {query_time:.6f} seconds")

        # Analyze the query
        query_sql = connection.queries[-1]['sql']
        print(f"SQL query: {query_sql}")

        # Check if query time is acceptable for an indexed field
        self.assertLess(query_time, 0.01, "emp_id lookup takes too long, might need an index")

    def test_index_on_department(self):
        """Test query performance with department field."""
        # department is used for filtering, so it should ideally be indexed

        reset_queries()
        settings.DEBUG = True

        start_time = time.time()
        employees = Employee.objects.filter(department='IT')
        query_time = time.time() - start_time

        self.assertTrue(employees.exists())
        print(f"Query time for department lookup: {query_time:.6f} seconds")
        print(f"Number of employees found: {employees.count()}")

        # Analyze the query
        query_sql = connection.queries[-1]['sql']
        print(f"SQL query: {query_sql}")

        # Check if query time is acceptable for an indexed field used for filtering
        self.assertLess(query_time, 0.01, "department lookup takes too long, might need an index")


def run_all_performance_tests():
    """Run all performance tests and generate a report."""
    from django.test.runner import DiscoverRunner
    test_runner = DiscoverRunner(verbosity=2)

    print("=" * 80)
    print("PERFORMANCE TEST REPORT")
    print("=" * 80)

    # Run database query profiling tests
    print("\nRUNNING DATABASE QUERY PROFILING TESTS")
    print("-" * 50)
    test_runner.run_tests(['employee_predictor.tests.test_performance.DatabaseQueryProfilingTest'])

    # Run page load optimization tests
    print("\nRUNNING PAGE LOAD OPTIMIZATION TESTS")
    print("-" * 50)
    test_runner.run_tests(['employee_predictor.tests.test_performance.PageLoadOptimizationTest'])

    # Run scalability tests
    print("\nRUNNING SCALABILITY TESTS")
    print("-" * 50)
    test_runner.run_tests(['employee_predictor.tests.test_performance.ScalabilityTest'])

    # Run index performance tests
    print("\nRUNNING INDEX PERFORMANCE TESTS")
    print("-" * 50)
    test_runner.run_tests(['employee_predictor.tests.test_performance.IndexPerformanceTest'])

    print("=" * 80)
    print("PERFORMANCE TEST REPORT COMPLETE")
    print("=" * 80)


if __name__ == '__main__':
    # This allows running the performance tests directly
    run_all_performance_tests()