# employee_predictor/tests/test_models.py
from django.test import TestCase
from django.contrib.auth.models import User
from django.utils import timezone
from datetime import timedelta, datetime, date
from decimal import Decimal

from employee_predictor.models import Employee, Attendance, Leave, Payroll, PerformanceHistory


class EmployeeModelTest(TestCase):
    def setUp(self):
        self.user = User.objects.create_user(
            username='testuser',
            password='testpassword'
        )

        self.employee = Employee.objects.create(
            user=self.user,
            name='Test Employee',
            emp_id='EMP001',
            department='IT',
            position='Developer',
            date_of_hire=date(2020, 1, 1),
            gender='M',
            marital_status='Single',
            age=30,
            race='White',
            hispanic_latino='No',
            recruitment_source='LinkedIn',
            salary=Decimal('60000.00'),
            engagement_survey=4.0,
            emp_satisfaction=4,
            special_projects_count=2,
            days_late_last_30=1,
            absences=3
        )

    def test_employee_creation(self):
        self.assertEqual(self.employee.name, 'Test Employee')
        self.assertEqual(self.employee.emp_id, 'EMP001')
        self.assertEqual(self.employee.user, self.user)

    def test_salary_as_float(self):
        self.assertEqual(self.employee.salary_as_float(), 60000.00)
        self.assertIsInstance(self.employee.salary_as_float(), float)

    def test_get_tenure_years(self):
        tenure = self.employee.get_tenure_years()
        self.assertIsInstance(tenure, float)

    def test_save_prediction_details(self):
        prediction_result = {
            'prediction_score': 3,
            'probabilities': {1: 0.1, 2: 0.2, 3: 0.6, 4: 0.1}
        }

        self.employee.save_prediction_details(prediction_result)
        self.assertEqual(self.employee.predicted_score, 3)
        self.assertEqual(self.employee.performance_score, 'Fully Meets')
        self.assertEqual(self.employee.prediction_confidence, 0.6)

    def test_get_performance_label(self):
        self.employee.predicted_score = 4
        self.assertEqual(self.employee.get_performance_label(), 'Exceeds Expectations')

        self.employee.predicted_score = 1
        self.assertEqual(self.employee.get_performance_label(), 'Performance Improvement Plan (PIP)')

    def test_get_performance_color(self):
        self.employee.predicted_score = 4
        self.assertEqual(self.employee.get_performance_color(), 'success')

        self.employee.predicted_score = 1
        self.assertEqual(self.employee.get_performance_color(), 'danger')


class AttendanceModelTest(TestCase):
    def setUp(self):
        self.employee = Employee.objects.create(
            name='Test Employee',
            emp_id='EMP001',
            department='IT',
            position='Developer',
            date_of_hire=date(2020, 1, 1),
            gender='M',
            marital_status='Single',
            salary=Decimal('60000.00'),
            engagement_survey=4.0,
            emp_satisfaction=4,
            special_projects_count=2,
            days_late_last_30=1,
            absences=3
        )

        self.attendance = Attendance.objects.create(
            employee=self.employee,
            date=date.today(),
            check_in=datetime.strptime('09:00', '%H:%M').time(),
            check_out=datetime.strptime('17:00', '%H:%M').time(),
            status='PRESENT',
            notes='Regular day'
        )

    def test_attendance_creation(self):
        self.assertEqual(self.attendance.employee, self.employee)
        self.assertEqual(self.attendance.status, 'PRESENT')

    def test_calculate_hours_worked(self):
        hours = self.attendance.calculate_hours_worked()
        self.assertEqual(hours, Decimal('8.00'))

    def test_on_leave_status(self):
        leave_attendance = Attendance.objects.create(
            employee=self.employee,
            date=date.today() - timedelta(days=1),
            status='ON_LEAVE',
            notes='Annual leave'
        )

        self.assertIsNone(leave_attendance.check_in)
        self.assertIsNone(leave_attendance.check_out)
        self.assertEqual(leave_attendance.hours_worked, Decimal('0.00'))


class LeaveModelTest(TestCase):
    def setUp(self):
        self.admin_user = User.objects.create_user(
            username='admin',
            password='adminpassword',
            is_staff=True
        )

        self.employee = Employee.objects.create(
            name='Test Employee',
            emp_id='EMP001',
            department='IT',
            position='Developer',
            date_of_hire=date(2020, 1, 1),
            gender='M',
            marital_status='Single',
            salary=Decimal('60000.00'),
            engagement_survey=4.0,
            emp_satisfaction=4,
            special_projects_count=2,
            days_late_last_30=1,
            absences=3
        )

        self.leave = Leave.objects.create(
            employee=self.employee,
            start_date=date.today(),
            end_date=date.today() + timedelta(days=3),
            leave_type='ANNUAL',
            status='PENDING',
            reason='Family vacation'
        )

    def test_leave_creation(self):
        self.assertEqual(self.leave.employee, self.employee)
        self.assertEqual(self.leave.leave_type, 'ANNUAL')
        self.assertEqual(self.leave.status, 'PENDING')

    def test_duration_days(self):
        duration = self.leave.duration_days()
        self.assertEqual(duration, 4)  # 4 days including start and end dates

    def test_approve_leave(self):
        self.leave.status = 'APPROVED'
        self.leave.approved_by = self.admin_user
        self.leave.save()

        self.assertEqual(self.leave.status, 'APPROVED')
        self.assertEqual(self.leave.approved_by, self.admin_user)


class PayrollModelTest(TestCase):
    def setUp(self):
        self.employee = Employee.objects.create(
            name='Test Employee',
            emp_id='EMP001',
            department='IT',
            position='Developer',
            date_of_hire=date(2020, 1, 1),
            gender='M',
            marital_status='Single',
            salary=Decimal('60000.00'),
            engagement_survey=4.0,
            emp_satisfaction=4,
            special_projects_count=2,
            days_late_last_30=1,
            absences=3
        )

        # Monthly salary: 5000.00
        self.payroll = Payroll.objects.create(
            employee=self.employee,
            period_start=date(2023, 1, 1),
            period_end=date(2023, 1, 31),
            basic_salary=Decimal('5000.00'),
            overtime_hours=Decimal('10.00'),
            overtime_rate=Decimal('20.00'),
            bonuses=Decimal('500.00'),
            deductions=Decimal('200.00'),
            tax=Decimal('800.00'),
            net_salary=Decimal('0.00'),  # Will be calculated by the model
            status='DRAFT'
        )

    def test_payroll_creation(self):
        self.assertEqual(self.payroll.employee, self.employee)
        self.assertEqual(self.payroll.status, 'DRAFT')

    def test_calculate_net_salary(self):
        # Basic salary + (overtime hours * rate) + bonuses - deductions - tax
        # 5000 + (10 * 20) + 500 - 200 - 800 = 5000 + 200 + 500 - 200 - 800 = 4700
        expected_net = Decimal('4700.00')
        calculated_net = self.payroll.calculate_net_salary()

        self.assertEqual(calculated_net, expected_net)
        self.assertEqual(self.payroll.net_salary, expected_net)  # Auto-calculated during save
