# employee_predictor/tests/test_ml.py
import os
import tempfile
import pandas as pd
import numpy as np
from django.test import TestCase
from django.conf import settings
from datetime import date
from decimal import Decimal

from employee_predictor.models import Employee
from employee_predictor.ml.feature_engineering import prepare_data_for_prediction, engineer_features
from employee_predictor.ml.predictor import PerformancePredictor


class FeatureEngineeringTest(TestCase):
    def setUp(self):
        # Create a test employee
        self.employee_data = {
            'emp_id': ['EMP001'],
            'name': ['Test Employee'],
            'date_of_hire': [date(2020, 1, 1)],
            'department': ['IT'],
            'position': ['Developer'],
            'gender': ['M'],
            'marital_status': ['Single'],
            'age': [30],
            'race': ['White'],
            'hispanic_latino': ['No'],
            'recruitment_source': ['LinkedIn'],
            'salary': [60000.00],
            'engagement_survey': [4.0],
            'emp_satisfaction': [4],
            'special_projects_count': [2],
            'days_late_last_30': [1],
            'absences': [3],
            'employment_status': ['Active']
        }

    def test_engineer_features(self):
        # This test will skip actual preprocessing if model/preprocessor is not available
        # It will still test the function call works without errors
        try:
            features = engineer_features(self.employee_data)
            # This might fail if model/preprocessor not available, which is fine
        except ValueError as e:
            if "Preprocessor not found" in str(e):
                # This is expected if testing without ML models
                self.skipTest("Preprocessor not found - skipping feature engineering test")
            else:
                # Other errors should still fail the test
                raise


class PerformancePredictorTest(TestCase):
    def setUp(self):
        # Create a test employee
        self.employee = Employee.objects.create(
            name='Test Employee',
            emp_id='EMP001',
            department='IT',
            position='Developer',
            date_of_hire=date(2020, 1, 1),
            gender='M',
            marital_status='Single',
            age=30,
            race='White',
            hispanic_latino='No',
            recruitment_source='LinkedIn',
            salary=Decimal('60000.00'),
            engagement_survey=4.0,
            emp_satisfaction=4,
            special_projects_count=2,
            days_late_last_30=1,
            absences=3
        )

        # Prepare employee data for prediction
        self.employee_data = {
            'emp_id': [self.employee.emp_id],
            'name': [self.employee.name],
            'date_of_hire': [self.employee.date_of_hire],
            'department': [self.employee.department],
            'position': [self.employee.position],
            'gender': [self.employee.gender],
            'marital_status': [self.employee.marital_status],
            'age': [self.employee.age],
            'race': [self.employee.race],
            'hispanic_latino': [self.employee.hispanic_latino],
            'recruitment_source': [self.employee.recruitment_source],
            'salary': [float(self.employee.salary)],
            'engagement_survey': [self.employee.engagement_survey],
            'emp_satisfaction': [self.employee.emp_satisfaction],
            'special_projects_count': [self.employee.special_projects_count],
            'days_late_last_30': [self.employee.days_late_last_30],
            'absences': [self.employee.absences],
            'employment_status': [self.employee.employment_status]
        }

    def test_rules_based_prediction(self):
        predictor = PerformancePredictor()

        # Test with employee data
        df = pd.DataFrame(self.employee_data)
        prediction = predictor.rules_based_prediction(df)

        # Check that prediction is within expected range (1-4)
        self.assertIn(prediction, [1, 2, 3, 4])

    def test_prediction_with_probability(self):
        predictor = PerformancePredictor()

        # Test with employee data
        result = predictor.predict_with_probability(self.employee_data)

        # Check result structure
        self.assertIn('prediction', result)
        self.assertIn('prediction_label', result)
        self.assertIn('probabilities', result)

        # Check that prediction is within expected range (1-4)
        self.assertIn(result['prediction'], [1, 2, 3, 4])

        # Check that probabilities sum to approximately 1
        probabilities_sum = sum(result['probabilities'].values())
        self.assertAlmostEqual(probabilities_sum, 1.0, places=1)