# employee_predictor/tests/test_views.py
from django.test import TestCase, Client
from django.urls import reverse
from django.contrib.auth.models import User
from django.utils import timezone
from datetime import date, timedelta
from decimal import Decimal
from employee_predictor.tests.test_helper import axes_login

from employee_predictor.models import Employee, Attendance, Leave, Payroll


class EmployeeListViewTest(TestCase):
    def setUp(self):
        # Create a staff user for authentication
        self.staff_user = User.objects.create_user(
            username='staffuser',
            password='staffpassword',
            email='staff@example.com',
            is_staff=True
        )

        # Create a non-staff user
        self.employee_user = User.objects.create_user(
            username='employeeuser',
            password='employeepassword',
            email='employee@example.com'
        )

        # Create sample employees
        Employee.objects.create(
            name='John Doe',
            emp_id='EMP001',
            department='IT',
            position='Developer',
            date_of_hire=date(2020, 1, 1),
            gender='M',
            marital_status='Single',
            salary=Decimal('60000.00'),
            engagement_survey=4.0,
            emp_satisfaction=4,
            special_projects_count=2,
            days_late_last_30=1,
            absences=3
        )

        Employee.objects.create(
            name='Jane Smith',
            emp_id='EMP002',
            department='HR',
            position='Manager',
            date_of_hire=date(2019, 5, 15),
            gender='F',
            marital_status='Married',
            salary=Decimal('75000.00'),
            engagement_survey=3.5,
            emp_satisfaction=3,
            special_projects_count=1,
            days_late_last_30=0,
            absences=2
        )

        # Create client
        self.client = Client()

    def test_employee_list_view_staff_access(self):
        # Login as staff
        axes_login(self.client, 'staffuser', 'staffpassword')

        # Access employee list view
        response = self.client.get(reverse('employee-list'))

        # Check response
        self.assertEqual(response.status_code, 200)
        self.assertTemplateUsed(response, 'employee_predictor/employee/list.html')
        self.assertEqual(len(response.context['employees']), 2)

    def test_employee_list_view_employee_access_denied(self):
        # Login as non-staff employee
        axes_login(self.client, username='employeeuser', password='employeepassword')

        # Try to access employee list view
        response = self.client.get(reverse('employee-list'))

        # Should be redirected to employee portal
        self.assertRedirects(response, reverse('employee-portal'))

    def test_employee_list_view_search_filter(self):
        # Login as staff
        axes_login(self.client, username='staffuser', password='staffpassword')

        # Search for 'John'
        response = self.client.get(reverse('employee-list'), {'search': 'John'})

        # Check that only John Doe is returned
        self.assertEqual(response.status_code, 200)
        self.assertEqual(len(response.context['employees']), 1)
        self.assertEqual(response.context['employees'][0].name, 'John Doe')

    def test_employee_list_view_department_filter(self):
        # Login as staff
        axes_login(self.client, username='staffuser', password='staffpassword')

        # Filter by HR department
        response = self.client.get(reverse('employee-list'), {'department': 'HR'})

        # Check that only Jane Smith is returned
        self.assertEqual(response.status_code, 200)
        self.assertEqual(len(response.context['employees']), 1)
        self.assertEqual(response.context['employees'][0].name, 'Jane Smith')


class LeaveApprovalTest(TestCase):
    def setUp(self):
        # Create a staff user for authentication
        self.staff_user = User.objects.create_user(
            username='staffuser',
            password='staffpassword',
            email='staff@example.com',
            is_staff=True
        )

        # Create an employee
        self.employee = Employee.objects.create(
            name='John Doe',
            emp_id='EMP001',
            department='IT',
            position='Developer',
            date_of_hire=date(2020, 1, 1),
            gender='M',
            marital_status='Single',
            salary=Decimal('60000.00'),
            engagement_survey=4.0,
            emp_satisfaction=4,
            special_projects_count=2,
            days_late_last_30=1,
            absences=3
        )

        # Create a pending leave request
        self.leave = Leave.objects.create(
            employee=self.employee,
            start_date=date.today() + timedelta(days=5),
            end_date=date.today() + timedelta(days=10),
            leave_type='ANNUAL',
            status='PENDING',
            reason='Family vacation'
        )

        # Create client
        self.client = Client()

    def test_approve_leave_request(self):
        # Login as staff
        axes_login(self.client, username='staffuser', password='staffpassword')

        # Approve the leave request
        response = self.client.get(
            reverse('leave-approve', args=[self.leave.id]),
            {'action': 'approve'}
        )

        # Check redirect
        self.assertRedirects(response, reverse('leave-list'))

        # Refresh the leave object from DB
        self.leave.refresh_from_db()

        # Check that leave status is updated
        self.assertEqual(self.leave.status, 'APPROVED')
        self.assertEqual(self.leave.approved_by, self.staff_user)

        # Check that attendance records were created for leave days
        attendance_count = Attendance.objects.filter(
            employee=self.employee,
            status='ON_LEAVE'
        ).count()

        # Should be 6 days (inclusive of start and end date)
        self.assertEqual(attendance_count, 6)

    def test_reject_leave_request(self):
        # Login as staff
        axes_login(self.client, username='staffuser', password='staffpassword')

        # Reject the leave request
        response = self.client.get(
            reverse('leave-approve', args=[self.leave.id]),
            {'action': 'reject'}
        )

        # Check redirect
        self.assertRedirects(response, reverse('leave-list'))

        # Refresh the leave object from DB
        self.leave.refresh_from_db()

        # Check that leave status is updated
        self.assertEqual(self.leave.status, 'REJECTED')
        self.assertEqual(self.leave.approved_by, self.staff_user)

        # Check that no attendance records were created
        attendance_count = Attendance.objects.filter(
            employee=self.employee,
            status='ON_LEAVE'
        ).count()

        self.assertEqual(attendance_count, 0)


class PayrollProcessingTest(TestCase):
    def setUp(self):
        # Create a staff user for authentication
        self.staff_user = User.objects.create_user(
            username='staffuser',
            password='staffpassword',
            email='staff@example.com',
            is_staff=True
        )

        # Create an employee
        self.employee = Employee.objects.create(
            name='John Doe',
            emp_id='EMP001',
            department='IT',
            position='Developer',
            date_of_hire=date(2020, 1, 1),
            gender='M',
            marital_status='Single',
            salary=Decimal('60000.00'),
            engagement_survey=4.0,
            emp_satisfaction=4,
            special_projects_count=2,
            days_late_last_30=1,
            absences=3
        )

        # Create a draft payroll
        self.payroll = Payroll.objects.create(
            employee=self.employee,
            period_start=date(2023, 1, 1),
            period_end=date(2023, 1, 31),
            basic_salary=Decimal('5000.00'),
            overtime_hours=Decimal('10.00'),
            overtime_rate=Decimal('20.00'),
            bonuses=Decimal('500.00'),
            deductions=Decimal('200.00'),
            tax=Decimal('800.00'),
            net_salary=Decimal('4700.00'),
            status='DRAFT'
        )

        # Create client
        self.client = Client()

    def test_process_payroll(self):
        # Login as staff
        axes_login(self.client, username='staffuser', password='staffpassword')

        # Process the payroll
        response = self.client.get(reverse('payroll-process', args=[self.payroll.id]))

        # Check redirect
        self.assertRedirects(response, reverse('payroll-detail', args=[self.payroll.id]))

        # Refresh the payroll object from DB
        self.payroll.refresh_from_db()

        # Check that payroll status is updated
        self.assertEqual(self.payroll.status, 'APPROVED')
        self.assertIsNotNone(self.payroll.payment_date)


class EmployeePerformancePredictionTest(TestCase):
    def setUp(self):
        # Create a staff user for authentication
        self.staff_user = User.objects.create_user(
            username='staffuser',
            password='staffpassword',
            email='staff@example.com',
            is_staff=True
        )

        # Create an employee
        self.employee = Employee.objects.create(
            name='John Doe',
            emp_id='EMP001',
            department='IT',
            position='Developer',
            date_of_hire=date(2020, 1, 1),
            gender='M',
            marital_status='Single',
            age=30,
            race='White',
            hispanic_latino='No',
            recruitment_source='LinkedIn',
            salary=Decimal('60000.00'),
            engagement_survey=4.0,
            emp_satisfaction=4,
            special_projects_count=2,
            days_late_last_30=1,
            absences=3
        )

        # Create client
        self.client = Client()

    def test_employee_prediction_view(self):
        # Login as staff
        axes_login(self.client, username='staffuser', password='staffpassword')

        # Update employee with prediction
        post_data = {
            'name': 'John Doe',
            'emp_id': 'EMP001',
            'department': 'IT',
            'position': 'Developer',
            'date_of_hire': '2020-01-01',
            'gender': 'M',
            'marital_status': 'Single',
            'age': 30,
            'race': 'White',
            'hispanic_latino': 'No',
            'recruitment_source': 'LinkedIn',
            'salary': '60000.00',
            'engagement_survey': 4.0,
            'emp_satisfaction': 4,
            'special_projects_count': 3,  # Increased from 2
            'days_late_last_30': 0,  # Decreased from 1
            'absences': 2,  # Decreased from 3
            'employment_status': 'Active'
        }

        # Send request to prediction view
        response = self.client.post(
            reverse('employee-predict', args=[self.employee.id]),
            data=post_data
        )

        # Check redirect to employee detail
        self.assertRedirects(response, reverse('employee-detail', args=[self.employee.id]))

        # Refresh employee from DB
        self.employee.refresh_from_db()

        # Check that prediction was made (using rules-based system if no ML model)
        self.assertIsNotNone(self.employee.predicted_score)
        self.assertIsNotNone(self.employee.prediction_date)