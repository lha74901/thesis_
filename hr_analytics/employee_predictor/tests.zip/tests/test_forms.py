from django.test import TestCase
from django.contrib.auth.models import User
from datetime import date, timedelta
from decimal import Decimal

from employee_predictor.models import Employee, Leave
from employee_predictor.forms import (
    EmployeeForm, LeaveForm, AttendanceForm, PayrollForm,
    BulkAttendanceForm, EmployeeRegistrationForm
)


class EmployeeFormTest(TestCase):
    def test_valid_data(self):
        form_data = {
            'name': 'Test Employee',
            'emp_id': 'EMP001',
            'department': 'IT',
            'position': 'Developer',
            'date_of_hire': '2020-01-01',
            'gender': 'M',
            'marital_status': 'Single',
            'age': 30,
            'race': 'White',
            'hispanic_latino': 'No',
            'recruitment_source': 'LinkedIn',
            'salary': Decimal('60000.00'),
            'engagement_survey': 4.0,
            'emp_satisfaction': 4,
            'special_projects_count': 2,
            'days_late_last_30': 1,
            'absences': 3,
            'performance_score': 'Exceeds',
            'employment_status': 'Active'
        }

        form = EmployeeForm(data=form_data)
        self.assertTrue(form.is_valid())

    def test_invalid_engagement_survey(self):
        form_data = {
            'name': 'Test Employee',
            'emp_id': 'EMP001',
            'department': 'IT',
            'position': 'Developer',
            'date_of_hire': '2020-01-01',
            'gender': 'M',
            'marital_status': 'Single',
            'age': 30,
            'race': 'White',
            'hispanic_latino': 'No',
            'recruitment_source': 'LinkedIn',
            'salary': Decimal('60000.00'),
            'engagement_survey': 6.0,  # Invalid: should be between 1 and 5
            'emp_satisfaction': 4,
            'special_projects_count': 2,
            'days_late_last_30': 1,
            'absences': 3,
            'performance_score': 'Exceeds',
            'employment_status': 'Active'
        }

        form = EmployeeForm(data=form_data)
        self.assertFalse(form.is_valid())
        self.assertIn('engagement_survey', form.errors)


class LeaveFormTest(TestCase):
    def setUp(self):
        self.employee = Employee.objects.create(
            name='Test Employee',
            emp_id='EMP001',
            department='IT',
            position='Developer',
            date_of_hire=date(2020, 1, 1),
            gender='M',
            marital_status='Single',
            salary=Decimal('60000.00'),
            engagement_survey=4.0,
            emp_satisfaction=4,
            special_projects_count=2,
            days_late_last_30=1,
            absences=3
        )

    def test_valid_leave_request(self):
        form_data = {
            'employee': self.employee.id,
            'start_date': date.today() + timedelta(days=5),
            'end_date': date.today() + timedelta(days=10),
            'leave_type': 'ANNUAL',
            'reason': 'Family vacation'
        }

        form = LeaveForm(data=form_data)
        self.assertTrue(form.is_valid())

    def test_end_date_before_start_date(self):
        form_data = {
            'employee': self.employee.id,
            'start_date': date.today() + timedelta(days=10),
            'end_date': date.today() + timedelta(days=5),  # End date before start date
            'leave_type': 'ANNUAL',
            'reason': 'Family vacation'
        }

        form = LeaveForm(data=form_data)
        self.assertFalse(form.is_valid())

    def test_overlapping_leave(self):
        # Create an existing approved leave
        Leave.objects.create(
            employee=self.employee,
            start_date=date.today() + timedelta(days=5),
            end_date=date.today() + timedelta(days=15),
            leave_type='ANNUAL',
            status='APPROVED',
            reason='Existing leave'
        )

        # Try to create an overlapping leave
        form_data = {
            'employee': self.employee.id,
            'start_date': date.today() + timedelta(days=10),
            'end_date': date.today() + timedelta(days=20),
            'leave_type': 'SICK',
            'reason': 'Overlapping leave'
        }

        form = LeaveForm(data=form_data)
        self.assertFalse(form.is_valid())


class EmployeeRegistrationFormTest(TestCase):
    def setUp(self):
        self.employee = Employee.objects.create(
            name='Test Employee',
            emp_id='EMP001',
            department='IT',
            position='Developer',
            date_of_hire=date(2020, 1, 1),
            gender='M',
            marital_status='Single',
            salary=Decimal('60000.00'),
            engagement_survey=4.0,
            emp_satisfaction=4,
            special_projects_count=2,
            days_late_last_30=1,
            absences=3
        )

        self.user = User.objects.create_user(
            username='existinguser',
            password='password123'
        )

    def test_valid_registration(self):
        form_data = {
            'employee_id': 'EMP001',
            'username': 'newuser',
            'password1': 'ComplexPassword123',
            'password2': 'ComplexPassword123'
        }

        form = EmployeeRegistrationForm(data=form_data)
        self.assertTrue(form.is_valid())

    def test_invalid_employee_id(self):
        form_data = {
            'employee_id': 'INVALID',
            'username': 'newuser',
            'password1': 'ComplexPassword123',
            'password2': 'ComplexPassword123'
        }

        form = EmployeeRegistrationForm(data=form_data)
        self.assertFalse(form.is_valid())
        self.assertIn('employee_id', form.errors)

    def test_username_already_exists(self):
        form_data = {
            'employee_id': 'EMP001',
            'username': 'existinguser',  # This username already exists
            'password1': 'ComplexPassword123',
            'password2': 'ComplexPassword123'
        }

        form = EmployeeRegistrationForm(data=form_data)
        self.assertFalse(form.is_valid())
        self.assertIn('username', form.errors)

    def test_passwords_dont_match(self):
        form_data = {
            'employee_id': 'EMP001',
            'username': 'newuser',
            'password1': 'ComplexPassword123',
            'password2': 'DifferentPassword123'
        }

        form = EmployeeRegistrationForm(data=form_data)
        self.assertFalse(form.is_valid())